/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20200715;

/**
 *
 * @author xvpow
 */
public class Ch2_7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	/*for (int i = 1 ; i <= 5 ; i++){
	    System.out.println(i);
	}*/
	int a=1,b=2,c=0,i=0;	
	for (i = ++a; i <=3 && b++ <=5;i++,c++ ){
	    System.out.print(i+" ");
	}
	//i = 2 a = 2 b=3 c = 0  pr:2
	// i =3 a = 2 b=4 c = 1  pr:3
	//i =4 a = 2  b =4  c = 2 
	System.out.println();
	System.out.println(a);//2
	System.out.println(b);//4
	System.out.println(c);//2
	System.out.println(i);//4
	
    }
}
