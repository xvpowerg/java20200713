/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20200715;

/**
 *
 * @author xvpow
 */
public class Ch2_12 {

    public static void main(String[] args) {
	//1維陣列宣告方式
	int[] array1 = new int[3];
	int array2[] = new int[3];
	 //只適用於宣告時初始化
	int[] array3 = {5,6,2,3};
	//[]不能加上長度
	//已宣告過想要重新建立一組有預設值的陣列
	int[] array4  = new int[]{2,1,5};	
	//array3 = {7,5,6,2,1};
	array3 = new int[]{7,5,6,2,1};
    }
    
}
