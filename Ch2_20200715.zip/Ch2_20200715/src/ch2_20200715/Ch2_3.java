/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20200715;

public class Ch2_3 {
    public static void main(String[] args) {
	
	//常數
	final int RUN = 1;
	final int JUMP = 2;
	final int WALK = 3;
	final float PI =  3.1415f;
	 int action = JUMP;
	
	//可傳參數類型
	//byte short int char String enum
	//用在　 case的變數必須是常數
	switch(action){
	    case RUN:
	System.out.println("跑");
            break;
	    case JUMP:
	System.out.println("跳");
	    break;
	    case WALK:
	System.out.println("走");
            break;		 
	    default:
	System.out.println("Error!");	
	    break;	
	}
	
	
    }
    
}
