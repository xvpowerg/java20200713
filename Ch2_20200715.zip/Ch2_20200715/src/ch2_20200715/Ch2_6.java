/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20200715;

/**
 *
 * @author xvpow
 */
public class Ch2_6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	//case 的數值大小會受到參數的影響
	byte by = 2;	//-128~127
	switch(by){
	    case 127:
	      break;
	    case 126:
	      break;
	}
	
	//case 的數值不可重複
	int level = 2;
	switch(level){
	    case 1:
		break;
	    case 10___0_00:
		  break;
	    case 2:
		break;
//	    case 10000:
//		break;		    
	}
	
	
	
    }
    
}
