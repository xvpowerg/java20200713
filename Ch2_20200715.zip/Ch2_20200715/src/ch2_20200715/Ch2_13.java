/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20200715;
import java.util.Arrays;
/**
 *
 * @author xvpow
 */
public class Ch2_13 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	int[] array = {15,18,20,6,3,11,9};
	// 3 6 9 11 15 18 20
	  Arrays.sort(array);
	  for (int v : array){
	      System.out.print(v+" ");
	  }
	  System.out.println();
	  //一定要排序
	int index = Arrays.binarySearch(array, 18);
	System.out.println(index);
	//找不到
	//比所有都小 index固定為-1
	index = Arrays.binarySearch(array, 2);
	System.out.println(index);
	//比所有都大 (長度+1)*-1
	index = Arrays.binarySearch(array, 22);
	System.out.println(index);
	//介於中間 搜尋數值的 下個數的長度 *-1
	index = Arrays.binarySearch(array, 8);
	System.out.println(index);
	index = Arrays.binarySearch(array, 16);
	System.out.println(index);
	index = Arrays.binarySearch(array, 10);
	System.out.println(index);
	
    }
    
}
