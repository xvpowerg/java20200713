/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20200715;

/**
 *
 * @author xvpow
 */
public class Ch2_9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	tag1:
	for (int i = 1; i <= 5; i++){
		System.out.println("Start:"+i);
	    for (int k = 1; k <= 3; k++){	
		//System.out.println("Test!!!"+i);
		//if(i==2) break tag1;
		if(i==2) continue tag1;
		System.out.print(i+":"+k+" ");
	    }	    
	     System.out.println();
	    System.out.println("End:"+i);
	}
	
	
	
    }
    
}
