/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20200715;

/**
 *
 * @author xvpow
 */
public class Ch2_4 {

    public static void main(String[] args) {
	//Pool
	String st1 = "Ken";
	String st2 = "Ken";
	String st3 = new String("Ken");
	System.out.println(st1);
	System.out.println(st2);
	System.out.println(st2 == st1);//true
	System.out.println(st3 == st1);//false
	System.out.println(st2.equals(st1));
	System.out.println(st2.equals(st3));	
	//null
	String name1 = null;
	String name2 = "Ken";
	System.out.println(name1.equals(name2));//java.lang.NullPointerException
	System.out.println(name2.equals(name1));
	
    }
    
}
