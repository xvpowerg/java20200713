/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20200715;
import java.util.Arrays;
import java.util.stream.Stream;
/**
 *
 * @author xvpow
 */
public class Ch2_11 {

    public static void main(String[] args) {
	//陣列預設值
	//整數 0
	//浮點數 0.0 
	//字元 空白字元
	//布林 false
	//其他 null
	
	//長度為5的陣列(箱子)
	int[] scores = new int[6];
	scores[0] = 75;
	scores[1] = 96;
	scores[2] = 83;
	scores[3] = 81;
	scores[4] = 100;

//	for (int i = 0;i < scores.length;i++){
//	    System.out.println("index:"+i+":"+scores[i]);
//	}
	
	for (int i =0;i < scores.length;i++){
	    int score = scores[i];
	    System.out.println(score);
	}
	 System.out.println("=========================");
	//foreach
	for (int score : scores){
	    System.out.println(score);
	}
	
	//Stream 最近流行的模式
	Arrays.stream(scores).
		forEach(System.out::println);
	
    }
    
}
