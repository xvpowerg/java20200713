/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20200715;

/**
 *
 * @author xvpow
 */
public class Ch2_2 {
    public static void main(String[] args) {
	 int i =30;
	 //當我的if語法下只有一條命令時 可以省略{}
	if (i < 20){
	  System.out.println("i小於20");
	  System.out.println("請輸入正確的數值!");
	}else if(i < 50)
	  System.out.println("i小於50");  
	
	
    }
    
}
