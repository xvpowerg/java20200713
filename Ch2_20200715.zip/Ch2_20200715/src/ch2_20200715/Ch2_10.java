/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20200715;

/**
 *
 * @author xvpow
 */
public class Ch2_10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	//for 適合用於知道長度 陣列 字串 
	//while 適合用於不知道長度 IO這類型的
	//do while 適合用於不知道長度 一定運行一次的情況 
	
	int i = 5;
	while (i >= 1 )
	    System.out.println(i--);
	
            System.out.println(i--);
	 System.out.println();
	int k= 1;
	do
	    System.out.println(k++);
	while(k <= 5);
	 System.out.println();
	 
	int y = 1;
	for (y = 2;y<=5;y++)
	    System.out.println(y);//2 3 4 5
	    System.out.println("value:"+y+20);
	
    }
    
}
