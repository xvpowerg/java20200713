/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20200715;

/**
 *
 * @author xvpow
 */
public class Ch2_1 {
    public static void main(String[] args) {
	
	//8進位
	//0表示8進位
	int oct = 0_12;
	//16進位 *
	//0x表示16進位
	//A = 10 B=11 C=12 D=13 E=14 F =15
	int color = 0xF10A0B;
	//2進位
	//0b表示二進位
	int signal = 0b0110110011;
	
	System.out.println(oct);
	System.out.println(color);
	System.out.println(signal);
    }
}
