/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20200715;

import java.util.Arrays;

public class Ch2_14 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    	int[] array = {5,6,9,2,3,1,4,7,8};	
	int[] copyArray = Arrays.copyOf(array, 6);
	for (int v :copyArray){
	    System.out.print(v+" ");
	}
	System.out.println();
	//2 指的是index 2
	//7 指的是 < 7的 index 
	copyArray = Arrays.copyOfRange(array, 2, 7);	
	for (int v :copyArray){
	    System.out.print(v+" ");
	}
	   System.out.println();
	int[] emptyArray = new int[10];
	Arrays.fill(emptyArray, -1);
	for (int v : emptyArray){
	    System.out.print(v+" ");
	}	
	
	int[] array2 = {5,6,9,2,3,1,4,7,8};	
	int[] copyArray2 = Arrays.copyOf(array2, 20);
	  System.out.println();
//	  for (int i = 0; i < copyArray2.length;i++){
//	      int v = copyArray2[i];
//	      System.out.print(v);
//	  }
	for (int v : copyArray2){
	     System.out.print(v+" ");
	 }	
    }
    

}
