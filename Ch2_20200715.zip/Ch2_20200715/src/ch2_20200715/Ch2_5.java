/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20200715;

/**
 *
 * @author xvpow
 */
public class Ch2_5 {
    public static void main(String[] args) {
	
	//String name = "Iris";
	String name = null;//java.lang.NullPointerException
	switch(name){
	    case "Vivin":
		System.out.println("業務");
		break;
	    case "Lindy":
		System.out.println("主管");
		break;
	    case "Iris":
		System.out.println("專案管理");
		break;
	    default:
		System.out.println("查無此人!");
		break;
	}
	
	
    }
    
}
