/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20200715;

/**
 *
 * @author xvpow
 */
public class Ch2_8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	//break 離開迴圈
	//continue 跳到下一次迴圈
	for (int i =1;i<=10;i++){
	    if (i == 5) break;
	    //if (i==5) continue;
	    System.out.print(i+" ");
	}
	
    }
    
}
