/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20200810;

/**
 *
 * @author xvpow
 */
public class Ch13_2 {
    
   
	static class TestResource{
		 int x = 0;
		 //同步化 第一種寫法
//		public synchronized void runX(){
//		    for (int i =1;i<=5;i++){
//			System.out.println("Start:"+x+":"+Thread.currentThread().getName());  
//			x++;
//			System.out.println("End:"+x+":"+Thread.currentThread().getName());  
//		    }		    
//		}
		 
		  //同步化 第二種寫法
	public  void runX(){
	    //this是我的鎖
		   synchronized(this){
			for (int i =1;i<=5;i++){
			   System.out.println("Start:"+x+":"+Thread.currentThread().getName());  
			   x++;
			   System.out.println("End:"+x+":"+Thread.currentThread().getName());  
		       }	
		   }
		   
	}
		 
	}
    
    public static void main(String[] args) {
	//資源搶占
	TestResource testRes = new TestResource();
	Thread th1 = new Thread(()->{
		testRes.runX();
	});
	Thread th2 = new Thread(()->{
		testRes.runX();
	});
	
	th1.start();
	th2.start();
	
	
	
		
	
	
    }
    
}
