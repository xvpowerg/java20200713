/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20200810;

/**
 *
 * @author xvpow
 */
public class Ch13_1 {
    public static void main(String[] args) {
	// TODO code application logic here
	//測試Thread 建立方式
	//運行TestThread
	
    }
    
}
