/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20200810;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.SQLException;

public class Ch13_8 {

    public static void main(String[] args)throws SQLException{
	String url = "jdbc:derby://localhost:1527/mydb";
	String user = "qwer";
	String password = "12345";
//  交易	　transaction
	    try(Connection con = DriverManager.getConnection(url, user, password);
		 Statement stem =   con.createStatement();){
		//交易開始
		con.setAutoCommit(false);
		stem.executeUpdate("INSERT INTO student(id,st_name,score)"
			+ "VALUES(213,'Gigi',83)");
		stem.executeUpdate("INSERT INTO student(id,st_name,score)"
			+ "VALUES(214,'Gigi',83)");
		//con.rollback();//rollback 之上的SQL不會執行
		stem.executeUpdate("INSERT INTO student(id,st_name,score)"
			+ "VALUES(215,'Gigi',83)");
		//交易完成
		con.commit();
	    }

    }
    
}
