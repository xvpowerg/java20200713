/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20200810;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;
import java.io.FileInputStream;
public class Ch13_7 {


    public static void main(String[] args) {
	Properties properties = new Properties();
	try{
	    properties.load(new FileInputStream("C:\\MyDir\\db.properties"));   
	}catch(Exception ex){  }
	
	String url = properties.getProperty("url");
	String user = properties.getProperty("user");
	String password = properties.getProperty("password");
	
	try(Connection con = 
		DriverManager.getConnection(url, user,password);
	    Statement stm=con.createStatement();
		){
	    String sql = "SELECT * FROM student";
	    ResultSet result = stm.executeQuery(sql);
	    while(result.next()){
		int id = result.getInt(1);
		//可用欄位名稱取值
		String name = result.getString("st_name");
		float score = result.getFloat(3);
		System.out.println(id+":"+name+":"+score);
	    }	    
	}catch(SQLException ex){
	    System.out.println(ex);
	}

    }
    
}
