/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20200810;

/**
 *
 * @author xvpow
 */
public class Ch13_3 {
    //死鎖  Deadlock 
    static class TestDeadlock{
	synchronized void test1(TestDeadlock t1,String msg){
		System.out.println("into test2..");
		t1.test2(msg);
	    }
	synchronized void test2(String value){
	    System.out.println(value);
	}    
    }
    
 
    public static void main(String[] args) {
	//1 飢餓 starvation lock 資源分配不均		
	//2 活鎖  Live Lock  做了互相抵銷的事
	//3 死鎖  Deadlock 
	// 1 一定有一個以上的Thread
	// 2 一定有資源等待事件 例如A等待B釋放了才能做某件事
	TestDeadlock testLock1 = new TestDeadlock();
	TestDeadlock testLock2 = new TestDeadlock();
	Thread t1 = new Thread(()->{
		testLock1.test1(testLock2, "lock1");
	});
	Thread t2 = new Thread(()->{
		testLock2.test1(testLock1, "lock2");
	});
	t1.start();
	t2.start();
	
    }
    
}
