/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20200810;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.SQLException;
public class Ch13_6 {
	//JDBC
    public static void main(String[] args) {
	String url = "jdbc:derby://localhost:1527/mydb";
	String user = "qwer";
	String password = "12345";
	
	try(Connection con = DriverManager.getConnection(url, user, password);
	     Statement stm =   con.createStatement();
		){
	    String sql = "INSERT INTO student(id,st_name,score) VALUES(100,'Joy',82)";
	    int count = stm.executeUpdate(sql);
	    if (count > 0){
		System.out.println("新增成功!");
	    }
	}catch(SQLException ex){
	    System.out.println(ex);
	}
	
	
	
    }
    
}
