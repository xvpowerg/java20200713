/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20200810;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;
public class Ch13_4 {

    public static void main(String[] args) {
	// TODO code application logic here
	ExecutorService es = Executors.newCachedThreadPool();
		    es.execute(()->{
		System.out.println("Start ...."+
			Thread.currentThread().getName());
	       for (int i =1; i<=5;i++) {
		   System.out.println(i);
		   try{
			TimeUnit.SECONDS.sleep(1);
		   }catch(Exception ex){}
	       }
	    System.out.println("End ....");	    
	    });
	
	//停止ExecutorService
	es.shutdown();
	
    }
    
}
