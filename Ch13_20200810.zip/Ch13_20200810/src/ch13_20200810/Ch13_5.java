/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20200810;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadLocalRandom;
public class Ch13_5 {
    public static void main(String[] args) {	
	ExecutorService es =   Executors.newFixedThreadPool(3);
//	for (int i= 1;i<=5;i++){
//	    es.execute(()->{
//	      System.out.println("name:"+Thread.currentThread().getName());
//	       try{TimeUnit.SECONDS.sleep(1);}catch(Exception ex){}
//	    });
//	}
//使用執行序時 請使用ThreadLocalRandom作為亂數產生工具
         Future<Integer> future = es.submit(()->{
	     int random = 
		     ThreadLocalRandom.current().nextInt(500);//0~499 之間的亂數
	     try{ TimeUnit.SECONDS.sleep(3);}catch(Exception ex){}	    
	   return random;
	 });
	 System.out.println("Start 1...");
	 
	 Thread th2 = new Thread(()->{
		try{
		  int random = future.get();
		  System.out.println(random);
	       }catch(Exception ex){}
	 });
	th2.start();
	 System.out.println("End 1...");	 
	es.shutdown();	
    }    
}
