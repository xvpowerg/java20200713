/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20200803;

import java.util.HashMap;

/**
 *
 * @author xvpow
 */
public class Ch10_11 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	HashMap<String,Integer> map = new HashMap<>();
	map.put("Ken",62);
	map.put("Lindy",94);
	map.put("Vivin",83);
	map.put("Iris",56);
	map.put("Join",85);
	
	System.out.println(map.containsKey("Iris"));
	System.out.println(map.isEmpty());
	//如果 map中有Lindy這組Key 就不呼叫put方法
	//當Key不存在put
	if (!map.containsKey("Lindy")){
	    map.put("Lindy", -100);
	}
	System.out.println(map.get("Lindy"));
	//當Key不存在put
	map.putIfAbsent("Iris", 0);
	System.out.println(map.get("Iris"));
	
	//如果Key存在 會執行參數的BiFunction
	map.merge("Ken", 78, (ov,nv)->{
	    System.out.println(ov+":"+nv);
	    return ov + nv;});
	System.out.println(map.get("Ken"));
	//如果Key不存在 會回傳參數中的數值 寫入map
	map.merge("Tom", 21, (ov,nv)->{
	    System.out.println(ov+":"+nv);
	    return ov + nv;});
	System.out.println(map.get("Tom"));
	
    }
    
}
