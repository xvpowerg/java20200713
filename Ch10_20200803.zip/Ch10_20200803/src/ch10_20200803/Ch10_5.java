/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20200803;
import java.util.TreeSet;
public class Ch10_5 {
    public static void main(String[] args) {
	// TODO code application logic here
	//TreeSet 可以排序 預設是由小到大
	TreeSet<Integer> treeSet = new TreeSet<>();
	treeSet.add(11);
	treeSet.add(2);
	treeSet.add(8);
	treeSet.add(5);
	treeSet.add(6);
	treeSet.add(5);	
	Ch10_3.printSet(treeSet);
	
	// n = 7  ceiling : 8 higher:8
	// n = 5 ceiling : 5 higher:6
	//n =  2  ceiling : 2 higher:5
	int n =  5;
	//如果找不到回傳null
	Integer ceiling = treeSet.ceiling(n);//會找set中 >=n的數值
	Integer higher = treeSet.higher(n);//會找set中 >n的數值
	System.out.println(ceiling+":"+higher);	
	// x = 5 floor:5 lower:2
	// x = 7 floor:5 lower:6
	int x = 7;	
	int floor = treeSet.floor(x); //會找set中 <=x的數值
        int lower = treeSet.lower(x);//會找set中 <=x的數值
	System.out.println(floor+":"+lower);
	
    }
    
}
