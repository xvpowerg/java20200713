/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20200803;
import java.util.TreeSet;
public class Ch10_6 {
    public static void main(String[] args) {
	Item i1 = new Item("Apple",1);
	Item i2 = new Item("Cherry",3);
	Item i3 = new Item("Kewi",2);
	Item i4 = new Item("MoMo",4);
	Item i5 = new Item("PineApple",0);
	Item i6 = new Item("Orange",3);
	TreeSet<Item> treeSet = new TreeSet<>();
	
	treeSet.add(i1);
	treeSet.add(i2);
	treeSet.add(i3);
	treeSet.add(i4);
	treeSet.add(i5);
	treeSet.add(i6);
	Ch10_3.printSet(treeSet);
	
	
	
    }
    
}
