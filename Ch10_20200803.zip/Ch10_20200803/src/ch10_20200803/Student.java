/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20200803;

/**
 *
 * @author xvpow
 */
public class Student {
    private String name;
    private int age;
   
    Student(String name,int age){
	   this.age = age;
	   this.name = name;
    }
    
    public String toString(){
	return name+":"+age;
    }
    
    public boolean equals(Object obj){	
	Student tmpSt =  (Student)obj;
	boolean result = 
		this.age == tmpSt.age  && 
		this.name.equals(tmpSt.name);
	return result;
    }
}
