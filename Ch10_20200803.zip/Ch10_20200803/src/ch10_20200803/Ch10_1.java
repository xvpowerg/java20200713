/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20200803;
import java.util.ArrayList;
import java.util.List;
public class Ch10_1 {

       public static void printList(List list){
	    list.forEach(v->System.out.print(v+" "));
	    System.out.println();
	}
       
    public static void main(String[] args) {
	ArrayList<Integer> list = new ArrayList<>();
	list.add(20);
	list.add(15);
	list.add(71);
	list.add(32);
	
	System.out.println(list.get(3));
	printList(list);	
	list.add(1, 89);
	printList(list);
	List<Integer> groupList = new ArrayList<>();
	groupList.add(101);
	groupList.add(102);
	groupList.add(103);
	list.addAll(groupList);	
	printList(list);
	//找看看List是否有此物件
	boolean findObj = list.contains(71);
	System.out.println(findObj);
	//找不到回傳-1
	int index = list.indexOf(32);
	System.out.println(index);
	list.add(5,15);
	printList(list);
	//由左往右找15 的index
        int index2 =  list.indexOf(15);
	System.out.println(index2);
	//由右往左找15的index
	int index3 = list.lastIndexOf(15);
	System.out.println(index3);
	
	list.remove(Integer.valueOf(101));
	printList(list);
	
	list.removeIf(v->v % 2 == 0);
	printList(list);
	list.replaceAll(v->v+2);
	printList(list);	
    }
    
}

