/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20200803;

import java.util.HashMap;

/**
 *
 * @author xvpow
 */
public class Ch10_12 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	HashMap<String,Integer> map = new HashMap<>();
	map.put("Ken",62);
	map.put("Lindy",94);
	map.put("Vivin",83);
	map.put("Iris",56);
	map.put("Join",85);
	//Key 存在 會執行Bifunction 參數為 Key Value
	//return 的內容會寫入Map
	map.compute("Lindy", (key,value)->{
	        System.out.println(key+":"+value);
	    return 10;});
	System.out.println(map.get("Lindy"));
	
	    //Key 不存在 會執行Bifunction 參數為 Key Value
	    //value的內容為null
	//return 的內容會寫入Map
	map.compute("Tom", (key,value)->{
	        System.out.println(key+":"+value);
	    return 52;});
	System.out.println(map.get("Tom"));
	
	
	
    }
    

    
}
