/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20200803;
import tw.com.test.Product;
import java.util.TreeSet;
public class Ch10_7 {
    
    static  class MyProduct extends Product implements Comparable<Product>{
	MyProduct(String name,int price){
	    super(name,price);
	}
	public int compareTo(Product p){
	    if (getPrice() < p.getPrice()){
		return -1;
	    }else if(getPrice() > p.getPrice()){
		return 1;
	    }
	    return 0;
	}
    }
    public static void main(String[] args) {
	Product p1 = new MyProduct("Apple Mac",52000);
	Product p2 = new MyProduct("Android Phone",18000);
	Product p3 = new MyProduct("iPhone 11",25000);
	Product p4 = new MyProduct("Ps5",27000);
	TreeSet<Product> set = new TreeSet<>();
	set.add(p1);
	set.add(p2);
	set.add(p3);
	set.add(p4);
	Ch10_3.printSet(set);
    }
    
}
