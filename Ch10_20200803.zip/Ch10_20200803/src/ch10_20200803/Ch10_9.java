/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20200803;

import java.util.TreeSet;
import tw.com.test.Product;
import java.util.Comparator;
public class Ch10_9 {
    public static void main(String[] args) {
	Product p1 = new Product("Apple Mac",52000);
	Product p2 = new Product("Android Phone",18000);
	Product p3 = new Product("iPhone 11",25000);
	Product p4 = new Product("Ps5",27000);
	Product p5 = new Product("iPad Pro",27000);
	Product p6 = new Product("xBox",18000);
	Comparator<Product> cmp =  Comparator.
		<Product,Integer>comparing(Product::getPrice).
		thenComparing(Product::getName).reversed();
	TreeSet<Product> treeSet = new TreeSet<>(cmp);
	treeSet.add(p1);
	treeSet.add(p2);
	treeSet.add(p3);
	treeSet.add(p4);
	treeSet.add(p5);
	treeSet.add(p6);
	Ch10_3.printSet(treeSet);
    }
    
}
