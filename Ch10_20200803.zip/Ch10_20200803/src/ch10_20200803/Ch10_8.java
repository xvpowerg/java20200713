/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20200803;

import tw.com.test.Product;
import java.util.TreeSet;
import java.util.Comparator;
public class Ch10_8 {
	static class MyComparator implements Comparator<Product>{
	    //p1 小於 p2 負數
	    //p1 大於 p2 正數
	    //p1 等於 p2 0
		public int compare(Product p1,Product p2){
		    if (p1.getPrice()  < p2.getPrice()){
			return -1;
		    }else if(p1.getPrice() > p2.getPrice()){
			return 1;
		    }
		    return p1.getName().compareTo(p2.getName());
		}
	}

    public static void main(String[] args) {
	Product p1 = new Product("Apple Mac",52000);
	Product p2 = new Product("Android Phone",18000);
	Product p3 = new Product("iPhone 11",25000);
	Product p4 = new Product("Ps5",27000);
	Product p5 = new Product("iPad Pro",27000);
	Product p6 = new Product("xBox",18000);
	MyComparator myComparator= new MyComparator();
	TreeSet<Product> treeSet = new TreeSet<>(myComparator);
	treeSet.add(p1);
	treeSet.add(p2);
	treeSet.add(p3);
	treeSet.add(p4);
	treeSet.add(p5);
	treeSet.add(p6);
	Ch10_3.printSet(treeSet);
	
    }
    
}
