/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20200803;

/**
 *
 * @author xvpow
 */
public class Item implements Comparable<Item>{
    private String itemName;
    private int id;
    
    // 假設目前的Item大於 傳入的Item 回傳正整數
    // 假設目前的Item小於 傳入的Item 回傳負整數
    // 假設目前的Item等於 傳入的Item 回傳0
    public int compareTo(Item item){
	if (id > item.id){
	    return 1;
	}else if(id < item.id){
	    return -1;
	}
	
	return itemName.compareTo(item.itemName);
    }
    
    
    public Item(String itemName,int id){
	this.itemName = itemName;
	this.id = id;
    }
    public String toString(){
	return itemName+":"+id;
    }
    //請覆寫equals 條件
    //當目前itemName 跟 id 與傳入的 itemName 與 id相同時就回傳true
    public boolean equals(Object obj){
	Item tmpItem = (Item)obj;	
	boolean result = this.id == tmpItem.id &&
			 this.itemName.
			  equals(tmpItem.itemName);
	return result;
    }
//1 如果 equals相同 那 hashCode必須相同
//2 hashCode 不可用亂數
//3 hashCode相同 那麼 equals不一定回傳true
    public int hashCode(){
         return id+itemName.hashCode();
    }
}
