/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20200803;
import java.util.Set;
import java.util.HashSet;
import java.util.List;
public class Ch10_3 {
      public static void printSet(Set set){
	    set.forEach(v->System.out.print(v+" "));
	    System.out.println();
	}    
   //Set 不可新增重複內容
    //會過濾重複
    //輪巡取數值順序與放入Set順序無法保證相同
    public static void main(String[] args) {
	Set<Integer> set = new HashSet<Integer>();
	set.add(50);
	set.add(71);
	set.add(15);
	set.add(32);
	set.add(15);
	set.add(18);
	printSet(set);
	
    }    
}
