/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20200803;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Set;
public class Ch10_10 {
    public static void main(String[] args) {
	HashMap<String,Integer> map = new HashMap<>();
	map.put("Ken",62);
	map.put("Lindy",94);
	map.put("Vivin",83);
	map.put("Iris",56);
	map.put("Join",85);
	//key重複會取代
	map.put("Ken",96);
	System.out.println(map.get("Iris"));
	System.out.println(map.get("Lindy"));
	System.out.println(map.get("Ken"));
	//輪巡Map
	//1
	Set<Entry<String,Integer>> set = map.entrySet();
	for (Entry e : set){
	    System.out.println(e.getKey()+":"+e.getValue());
	}
	//2
	map.forEach((k,v)->System.out.println(k+":"+v));
    }
    
}
