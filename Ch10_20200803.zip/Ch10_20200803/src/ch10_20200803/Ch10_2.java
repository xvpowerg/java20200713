/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20200803;
import java.util.ArrayList;
import java.util.List;
public class Ch10_2 {
 
    public static void main(String[] args) {
	Student st1 = new Student("Ken",16);
	Student st2 = new Student("Vivin",25);
	Student st3 = new Student("Join",38);
	Student st4 = new Student("Lindy",42);
	
	Student st5 = new Student("Join",38);
	
	List<Student> stList = new ArrayList<>();
	stList.add(st1);
	stList.add(st2);
	stList.add(st3);
	stList.add(st4);	
	Ch10_1.printList(stList);
	
	System.out.println(st5.equals(st3));
	stList.remove(st5);
	Ch10_1.printList(stList);
	
    }
    
}
