/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20200803;
import java.util.Set;
import java.util.HashSet;
public class Ch10_4 {
    public static void main(String[] args) {
	Item i1 = new Item("Apple",1);
	Item i2 = new Item("Kewi",2);
	Item i3 = new Item("Cherry",3);
	Item i4 = new Item("Cherry",3);
	
	System.out.println(i3.equals(i4));
	Set<Item> set = new HashSet<>();
	set.add(i1);
	set.add(i2);
	set.add(i3);
	set.add(i4);
	Ch10_3.printSet(set);
    }
    
}
