/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_20200729;

/**
 *
 * @author xvpow
 */
public interface MyInterface {
     void test1();
     //default方法 介面繼承時會繼承
     //default方法通常會呼叫介面的其他抽象方法
     //可以避免不必要的覆寫
     default void runTest1(){
	 System.out.println("AAA");
	 test1();
	 System.out.println("BBBB");
     }
     //static 方法 介面繼承不會繼承
     //工具類型的方法
     //可節省記憶體空間 因為靜態的為共享
     static int max(int a,int b){
	 return a > b ? a : b;
     }
}
