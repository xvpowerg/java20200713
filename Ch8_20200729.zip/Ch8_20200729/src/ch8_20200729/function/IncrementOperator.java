/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_20200729.function;
import java.util.function.UnaryOperator;
/**
 *
 * @author xvpow
 */
public class IncrementOperator implements  UnaryOperator<Integer>{
    public Integer apply(Integer value){
	return value + 1;
    }
}
