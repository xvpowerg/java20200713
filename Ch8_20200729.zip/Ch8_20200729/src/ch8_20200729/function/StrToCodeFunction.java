/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_20200729.function;
import java.util.function.Function;
public class StrToCodeFunction implements Function<String,int[]> {
    public int[] apply(String str){
	char[] charyArray =   str.toCharArray();
	int[] codeArray = new int[charyArray.length];
	for (int i =0;i <charyArray.length;i++){
	    //字元轉換為Unicode
	     codeArray[i] = charyArray[i];
	}
	return codeArray;
    }
}
