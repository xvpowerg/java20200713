/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_20200729.function;
import java.util.function.Supplier;
import java.util.Collection;
import java.util.ArrayList;

public class ListSupplier implements Supplier<Collection> {
    //提供一組ArrayList 作為收集之用
    public Collection get(){
	return new ArrayList();
    }
}
