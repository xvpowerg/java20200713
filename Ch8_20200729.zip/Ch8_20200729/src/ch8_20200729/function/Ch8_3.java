/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_20200729.function;
import java.util.function.Consumer;
import java.util.function.Supplier;
import java.util.ArrayList;
import java.util.Collection;
import java.util.function.Predicate;
public class Ch8_3 {
    //使用Consumer 搭配一組 整數陣列完成 某些功能   
    static void testConsumer(int[] array,
	    Consumer<Integer> consumer  ){	
	for (int v : array){
	     consumer.accept(v);
	}
    }
    //Supplier 希望提供一個物件去收集array 
    static Collection testSupplier(int[] array,
			  Supplier<Collection> supplier){
  	Collection c = supplier.get();
	for (int v : array){
	    c.add(v);
	}
	return  c;
    }
    //Predicate 
    // 滿足任意條件就顯示
    //Predicate 就等條件
    static void printArrayForCondition(int[] array,
	    Predicate<Integer>condition){
	for (int v : array){
	    if (condition.test(v)){
		System.out.print(v+" ");
	    }
	}
	System.out.println();
    }
    
    public static void main(String[] args) {
	// TODO code application logic here
	int[] myArray = {5,7,8,9,11,3}; 
	//Consumer void	accept(T t) //消費者 接收者 
	PrintConsumer pc = new PrintConsumer();
	testConsumer(myArray,pc);
	SumConsumer sum = new SumConsumer();
	testConsumer(myArray,sum);
	System.out.println(sum.getSum());

	//Supplier<T> T	get() //生產者 提供產品
//	ListSupplier lisSupp = new ListSupplier();
//	Collection<Integer> c1 =   testSupplier(myArray,lisSupp);
	TreeSupplier ts = new TreeSupplier();
	Collection<Integer> c1 =   testSupplier(myArray,ts);
	for (int v : c1){
	    System.out.print(v+" ");
	}
	System.out.println();
	
	 //Predicate<T> boolean	test(T t) //驗證條件是否成立
	 TestPredicatePrintOdd tpo = new TestPredicatePrintOdd();
	 printArrayForCondition(myArray,tpo);
	
	
	 
    }
    
}
