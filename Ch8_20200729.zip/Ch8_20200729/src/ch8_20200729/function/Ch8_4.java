/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_20200729.function;

import java.util.function.Function;
import java.util.function.UnaryOperator;
public class Ch8_4 {
    //字串 轉換成 Unicode陣列

    static int[] stringToUnicode(String src, Function<String, int[]> toUincode) {
	return toUincode.apply(src);
    }
 
    static void calculateArray(int[] array,UnaryOperator<Integer> uo){
	    for (int i =0; i < array.length;i++){
		int v = array[i];
		array[i] = uo.apply(v);
	    }
    }

    public static void main(String[] args) {
	// Function<T,R>   R	apply(T t) //轉換的過程 
	//T 表示傳入的類型
	//R 表示回傳的類型
	StrToCodeFunction strToCodeFun = new StrToCodeFunction();
	int[] codeArray = stringToUnicode("ABCDEF", strToCodeFun);
	for (int code : codeArray) {
	    System.out.print(code + " ");
	}
	System.out.println();
	
	// UnaryOperator<T> 是繼承了Function //累加累減 一元運算  進來的類型等於出去的類型
	int[] array2 = {23,67,85,92};
	IncrementOperator io = new IncrementOperator();
	calculateArray(array2,io);
	PrintConsumer pc = new PrintConsumer();
	Ch8_3.testConsumer(array2,pc);
    }

}
