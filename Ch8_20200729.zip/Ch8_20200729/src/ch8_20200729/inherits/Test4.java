/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_20200729.inherits;

/**
 *
 * @author xvpow
 */
//以下介面如不修改時會出錯
// 修改方案如下 以下方法案選一種
//1 改變Test1或Test3的default方法名稱
//2 覆寫Test1或Test3重複的default方法
//3 Test3 去繼承 Test2 可編譯通過的原因,為Test3的方法覆寫了Test1的method1方法
// 所以java知道要呼叫Test3的method1方法

public interface Test4 extends Test2,Test3 {
//    public default void method1(){
//	System.out.println("Test4 method1");
//    }
}
