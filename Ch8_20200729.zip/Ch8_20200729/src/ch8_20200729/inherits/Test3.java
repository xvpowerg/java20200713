/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_20200729.inherits;
public interface Test3 extends Test2{
      public default void  method1(){
	System.out.println("Test3 method1!!");
    }
}