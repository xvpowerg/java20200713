/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20200805;

import java.util.HashMap;

/**
 *
 * @author xvpow
 */
public class Ch11_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	HashMap<String,Integer> map = new HashMap<>();
	map.put("Ken",62);
	map.put("Lindy",94);
	map.put("Vivin",83);
	map.put("Iris",56);
	map.put("Join",85);
	
	//Key 存在 會執行Bifunction 參數為 Key Value
	//return 的內容會寫入Map
	map.compute("Lindy", (key,value)->{
	        System.out.println(key+":"+value);
	    return 10;});
	System.out.println(map.get("Lindy"));	
	    //Key 不存在 會執行Bifunction 參數為 Key Value
	    //value的內容為null
	//return 的內容會寫入Map
	map.compute("Tom", (key,value)->{
	        System.out.println(key+":"+value);
	    return 52;});
	System.out.println(map.get("Tom"));
	
	//Key 存在 不會執行computeIfAbsent 
	map.computeIfAbsent("Iris", (v1)->{
				System.out.println("IfAbsent v1:"+v1);
				return 25;});
	//Key 不存在 會執行computeIfAbsent 參數為 Key
	 //return 值會寫入Map
	map.computeIfAbsent("Lucy",v2->{
		System.out.println("IfAbsent v2:"+v2);
	    return 25;
	});
	System.out.println(map.get("Lucy"));
	
	
	//Key 存在 會執行computeIfPresent
	//參數是key與value 
	//value的內容為 原本在Map內的數值
	//return 的數值會取代Map的value
	map.computeIfPresent("Vivin", (k,v)->{		
	    System.out.println("IfPresent: "+k+":"+v);
	    return 95;
	});
	System.out.println(map.get("Vivin"));
	//Key 不存在 不會執行computeIfPresent 
	map.computeIfPresent("Neor", (k,v)->{		
	    System.out.println("IfPresent: "+k+":"+v);
	    return 95;
	});
	System.out.println(map.get("Neor"));
    }
    
}
