/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20200805;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;
import java.util.Comparator;
public class Ch11_6 {

    public static void main(String[] args) {
	List<Student> list = new ArrayList<>();
	list.add(new Student("Ken",80));
	list.add(new Student("Vivin",70));
	list.add(new Student("Iris",80));
	list.add(new Student("Lindy",90));
	list.add(new Student("Tom",70));
	list.add(new Student("Lucy",70));
	list.add(new Student("Joy",90));
	 Comparator<Student>  comp = 
		 Comparator.<Student,Integer>comparing(st->st.getScore()).
			 thenComparing(st->st.getName());
	TreeMap<Student,Integer> map = new TreeMap<>(comp);
	
	for (Student st : list){
	    map.put(st, st.getScore());
	}
	map.forEach((k,v)->System.out.println( k+":"+v));
	
    }
    
}
