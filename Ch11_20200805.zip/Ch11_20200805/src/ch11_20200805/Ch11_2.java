/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20200805;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
public class Ch11_2 {

   //Map 與群組有關
    public static void main(String[] args) {
	List<Student> list = new ArrayList<>();
	list.add(new Student("Ken",80));
	list.add(new Student("Vivin",70));
	list.add(new Student("Iris",80));
	list.add(new Student("Lindy",90));
	list.add(new Student("Tom",70));
	list.add(new Student("Lucy",70));
	list.add(new Student("Joy",90));
//	80:Ken Iris 
//	70:Vivin Tom Lucy
//	90 Lindy Joy
	//需求幫我把成績相同的分為一個群組
	Map<Integer,List<Student>> map = new HashMap();
	for(Student st: list){
	    List<Student> groupList = new ArrayList<>();
	    int key = st.getScore();
	    if (map.containsKey(key)){
		groupList = map.get(key);
	    }
	    	groupList.add(st);
		map.put(key, groupList);
	}

	System.out.println(map);
	
    }
    
}
