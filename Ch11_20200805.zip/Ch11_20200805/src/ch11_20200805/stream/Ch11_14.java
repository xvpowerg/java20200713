/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20200805.stream;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
/**
 *
 * @author xvpow
 */
public class Ch11_14 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	List<String> dataList = new ArrayList<>();
	dataList.add("Ken");
	dataList.add("Vivin");
	dataList.add("Lindy");
	dataList.add("Joy");
	
	dataList.stream().filter(v->v.length() > 3).
		forEach(n->System.out.println(n));
	//呼叫 parallel() 使得運行分散在多個CPU核心
	Optional<String>  optionData 
		    = dataList.stream().parallel().findAny();
	if (optionData.isPresent()){
	    System.out.println("optionData:"+optionData.get());
	}
	
	Optional<String> optionData2 =  
			dataList.stream().findFirst();
	optionData2.ifPresent(v->{
		System.out.println("optionData2:"+v);
	});
	
	
	
    }
    
}
