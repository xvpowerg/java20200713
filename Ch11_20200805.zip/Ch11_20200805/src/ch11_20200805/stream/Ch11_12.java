/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20200805.stream;
import java.util.List;
import java.util.ArrayList;
public class Ch11_12 {
    

    public static void main(String[] args) {
	// TODO code application logic here
	List<String> dataList = new ArrayList<>();
	dataList.add("Ken");
	dataList.add("Vivin");
	dataList.add("Lindy");
	dataList.add("Joy");
	//所有條件都符合回傳true
	boolean b1 =  dataList.stream().allMatch(s->s.length() > 2);
	System.out.println(b1);
	//只要其中一個符合回傳true
	boolean b2 = dataList.stream().anyMatch(s->s.endsWith("y"));
	System.out.println(b2);
	//不可有任何條件符合回傳true
	boolean b3 = dataList.stream().noneMatch(s->s.length() < 1);
	System.out.println(b3);
	
	// allMatch anyMatch noneMatch
	// 以上都有短路現象 達到某條件就不繼續驗證條件
	
	//只要找到一個條件不符合就不繼續驗證其他條件
	dataList.stream().peek(v->System.out.println("v:"+v)).
		    allMatch(s->s.length() > 3);
	System.out.println("=================================");
	//只要找到一個條件符合就不繼續驗證其他條件
	dataList.stream().peek(v->System.out.println("v2:"+v)).
		    anyMatch(s->s.length() > 3);
	//只要找到一個條件符合就不繼續驗證其他條件
	 dataList.stream().peek(v->System.out.println("v3:"+v)).
			noneMatch(s->s.length() < 5);
    }
    
}
