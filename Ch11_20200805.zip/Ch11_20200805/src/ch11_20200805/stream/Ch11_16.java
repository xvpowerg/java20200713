/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20200805.stream;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author xvpow
 */
public class Ch11_16 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	List<String> dataList = new ArrayList<>();
	dataList.add("Ken");
	dataList.add("Vivin");
	dataList.add("Lindy");
	dataList.add("Joy");
	//輸出會轉成基本型態
	dataList.stream().mapToInt(v->v.length()).forEach(
		(v)->System.out.println(v));
	
	dataList.stream().limit(2).forEach(System.out::println);
	System.out.println("================");
	dataList.stream().skip(1).forEach(System.out::println);
    }
    
}
