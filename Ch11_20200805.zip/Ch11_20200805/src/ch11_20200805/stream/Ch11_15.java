/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20200805.stream;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author xvpow
 */
public class Ch11_15 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	List<String> dataList = new ArrayList<>();
	dataList.add("Ken");
	dataList.add("Vivin");
	dataList.add("Lindy");
	dataList.add("Joy");
	//map 做轉換
	dataList.stream().map(v->{
	    int[] array = new int[v.length()];
	     char[] charArray  = v.toCharArray();
	     for (int i = 0;i<charArray.length;i++){
		 array[i] = charArray[i];
	     }
	    return array;
	}).forEach(v->System.out.println(v.length));
		
		
//		forEach(i->{
//		for (int v: i){
//		    System.out.print(v+" ");
//		}
//	        System.out.println();
//	});
    }
    
}
