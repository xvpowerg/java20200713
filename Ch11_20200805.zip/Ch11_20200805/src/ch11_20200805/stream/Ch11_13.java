/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20200805.stream;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;
public class Ch11_13 {

    public static void main(String[] args) {
	
	//Stream 特性
	//1 Stream不可修改來源
	//2 Stream不可重複使用
	//3 Stream有兩類第一類是lazy 第二類是Terminal
	//lazy 這個Stream方法不會立刻執行
	//Terminal 這個Stream方法會立刻執行
	List<String> dataList = new ArrayList<>();
	dataList.add("Ken");
	dataList.add("Vivin");
	dataList.add("Lindy");
	dataList.add("Joy");
	
//	 Stream<String> st1 =  dataList.stream();
//	 st1.noneMatch(v->v.length() > 2);
//	 st1.anyMatch(v->v.length() < 5);//拋出錯誤 因為重複使用Stream
	 Stream<String> st2 =  dataList.stream();
	 long count = st2.peek(v->System.out.println("v1:"+v)).count();
	 System.out.println(count);
    }
    
}
