/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20200805;
import java.util.TreeMap;
public class Ch11_5 {
    public static void main(String[] args) {
	//TreeMap用Key作為排序條件
	TreeMap<Integer,String> treeMap = new TreeMap<>();
	treeMap.put(25, "Ken");
	treeMap.put(5, "Vivin");
	treeMap.put(10, "Lindy");
	treeMap.put(7, "Lucy");
	treeMap.put(2, "Tom");
	
	treeMap.forEach((k,v)->System.out.println(k+":"+v));
    }
    
}
