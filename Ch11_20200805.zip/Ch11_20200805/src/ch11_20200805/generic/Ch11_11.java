/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20200805.generic;

/**
 *
 * @author xvpow
 */
public class Ch11_11 {

   
    public static void main(String[] args) {
	// TODO code application logic here
	TestFunction tfun = new TestFunction();
	//方法泛型的回傳值的類型可由參數類型決定
	int value =  tfun.genrate(()->50);
	String name = tfun.genrate(()->"Ken");
	
    String[] names =  tfun.transform("Ken,Vivin,Lindy",
	    (v)->{
	     return  v.split(",");
	});
	for (String n : names){
	    System.out.println(n);
	}
	
    }
    
}
