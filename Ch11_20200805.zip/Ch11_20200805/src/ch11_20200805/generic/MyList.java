/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20200805.generic;
import java.util.List;
import java.util.ArrayList;
import java.util.function.Consumer;
public class MyList<T> {
    private List<T> list = new ArrayList<>();
    
    public void add(T value){
	list.add(value);
    }
    public T get(int index){	
	return list.get(index);
    }
    public void foreach(Consumer<T> consumer){
	list.forEach(consumer);
    }
}
