/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20200805.generic;
import java.util.ArrayList;
import java.util.List;
public class Ch11_10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	//在一般情況下 左右邊泛型必須一樣
	List<Test1> list1 = new ArrayList<Test1>();
	List<Test2> myList =  new ArrayList<Test2>();
	myList.add(new Test2());
	myList.add(new Test2());
	//右邊泛型是子類型時可放到list2
	List<? extends Test1> list2 = myList;
	//list2 無法新增內容 但可以顯示
	//list2.add(new Test2());
	for (Test1 t1 :list2){
	    System.out.println(t1);
	}
	//右邊泛型是父類型時可放到list3
	List<? super Test2> list3 = new ArrayList<Test1>();
	//可新增但是類型必須是Test2
	list3.add(new Test2());
	list3.add(new Test2());
	//可取值但是類型必須是Object
	 Object t2 = list3.get(0);
	
    }
    
}
