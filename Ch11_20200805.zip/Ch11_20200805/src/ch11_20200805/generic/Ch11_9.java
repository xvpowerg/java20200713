/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20200805.generic;

/**
 *
 * @author xvpow
 */
public class Ch11_9 {

    public static void main(String[] args) {
	//泛型
	MyList myList = new MyList();
	myList.add("Ken");
	myList.add("Lindy");
	myList.add("Vivin");
	myList.foreach(System.out::println);
	
	MyList<Integer> myList2 = new MyList();	
	myList2.add(10);
	myList2.add(20);
	
    }
    
}
