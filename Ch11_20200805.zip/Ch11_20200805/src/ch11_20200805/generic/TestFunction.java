/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20200805.generic;
import java.util.function.Supplier;
import java.util.function.Function;
public class TestFunction {
    public <R> R genrate(Supplier<R> supp){
	return supp.get();
    }
    
    public  <T,R> R transform(T a,
	    Function<T,R> f1){
	return f1.apply(a);
    }
    
}
