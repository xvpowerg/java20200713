/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20200805;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author xvpow
 */
public class Ch11_4 {
    public static void main(String[] args) {
	List<Student> list = new ArrayList<>();
	list.add(new Student("Ken",80));
	list.add(new Student("Vivin",70));
	list.add(new Student("Iris",80));
	list.add(new Student("Lindy",90));
	list.add(new Student("Tom",70));
	list.add(new Student("Lucy",70));
	list.add(new Student("Joy",90));
	
	Map<Integer,List<Student>> map = new HashMap();	
	for (Student st: list){
	    int key  =st.getScore();
	    List<Student> tmpList = new ArrayList();
	    tmpList.add(st);
	    map.merge(key, tmpList, (ov,nv)->{
		ov.addAll(nv);
		return ov;
	    });
	}	
	System.out.println(map);
    }
    
}
