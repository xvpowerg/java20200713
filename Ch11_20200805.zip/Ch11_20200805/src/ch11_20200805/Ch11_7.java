/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20200805;

/**
 *
 * @author xvpow
 */
public class Ch11_7 {
    //列舉好處限定範圍
    enum Action{
	PLAY,
	STOP,
	EXIT
    }
    
    public static void main(String[] args) {
	Action action = Action.EXIT;
	switch(action){
	    case PLAY:
		System.out.println("運行!");
		break;
	    case STOP:
		System.out.println("停止!");
		break;
	    case EXIT:
		System.out.println("離開!");
		break;
	}
	
	
    }
    
}
