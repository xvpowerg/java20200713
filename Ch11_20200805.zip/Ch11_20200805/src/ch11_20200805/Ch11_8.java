/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20200805;

/**
 *
 * @author xvpow
 */
public class Ch11_8  {
    	enum Fruit{//我是繼承了enum的Fruit的類別
	    APPLE,//我是Fruit的物件
	    CHERRY,
	    BANANA
	}
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	//可以用字串轉會為列舉
	Fruit f1 = Fruit.valueOf("CHERRY");
	System.out.println(f1);
	//f1 = Furit.valueOf("Kiwi");//拋出例外
	//找出所有列舉
	Fruit[] fruits =   Fruit.values();
	for (Fruit f : fruits){
	    System.out.println(f);
	}
	
	System.out.println(Fruit.CHERRY.ordinal());
	System.out.println(Fruit.BANANA.ordinal());
	System.out.println(Fruit.BANANA.name());
	
    }
    
}
