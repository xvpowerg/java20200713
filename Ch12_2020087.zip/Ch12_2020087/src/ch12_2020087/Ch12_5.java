/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_2020087;
import java.time.LocalTime;
public class Ch12_5 {
    public static void main(String[] args) {
	// TODO code application logic here
    	LocalTime loclaTime =  LocalTime.now();
	System.out.println(loclaTime);
	System.out.println(loclaTime.getHour()+":"+
		    loclaTime.getMinute()+":"+loclaTime.getSecond());
	//最少　要傳入　小時　分鐘
	//LocalXXX 系列的特性　所有非靜態方法都不會改變自己　會回傳一組新的LocalXXX
	LocalTime newLoclaTime = LocalTime.of(13, 25);
	System.out.println(newLoclaTime);
	
	LocalTime minusTime=  newLoclaTime.minusHours(2);	
	System.out.println(minusTime);
	
	LocalTime minusTime2 = newLoclaTime.minusMinutes(50);
	System.out.println(minusTime2);

	
		
    }
    
}
