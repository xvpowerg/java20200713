/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_2020087.nio;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.io.IOException;
public class Ch12_12 {

    public static void main(String[] args) {
	Path source = Paths.get("c:", "mydir","test.zip");
	Path target = Paths.get("c:", "mydir","test_copy.zip");
	try{
	    Files.copy(source, target,StandardCopyOption.REPLACE_EXISTING);
	}catch(IOException ex){
	    System.out.println(ex);
	}
	
    }
    
}
