/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_2020087;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
public class Ch12_1 {
    public static void main(String[] args) {
	ArrayList<String> list1 = new ArrayList<>();
	ArrayList<String> list2 = new ArrayList<>();
	ArrayList<String> list3 = new ArrayList<>();
	list1.add("Apple");
	list1.add("Banana");
	list1.add("Cherry");
	
	list2.add("Vivin");
	list2.add("Lindy");
	list2.add("Joy");
	
	list3.add("Ken");
	list3.add("Iris");
	HashMap<Integer,ArrayList<String>> map = new HashMap<>();

	map.put(0, list1);
	map.put(1, list2);
	map.put(2, list3);
	
	List<HashMap<Integer,ArrayList<String>>> listMap = new ArrayList<>();
	listMap.add(map);
	
	//forEach 產出Stream<ArrayList<String>>
	//listMap.stream().map(m->m.values().stream()).forEach(action);

	//stream 內包含一個集合 可使用flatMap
	//flatMap 一定回傳Stream
	listMap.stream().flatMap(m->m.values().stream()).
		forEach(list->System.out.println(list));

	listMap.stream().
		flatMap(m->m.values().stream()).
		flatMap(list->list.stream()).
		filter(s->s.length() > 3).
		forEach(System.out::println);
	
	
    }
    
}
