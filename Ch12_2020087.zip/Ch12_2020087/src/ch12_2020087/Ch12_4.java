/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_2020087;
import java.util.Calendar;
import java.time.LocalDate;
public class Ch12_4 {

    public static void main(String[] args) {
	Calendar calender = Calendar.getInstance();
	int year = calender.get(Calendar.YEAR);
	int month = calender.get(Calendar.MONTH)+1;
	int date = calender.get(Calendar.DATE);
	System.out.println(year+"/"+month+"/"+date);
	
	LocalDate localDate =  LocalDate.now();
	System.out.println(localDate);
	System.out.println(localDate.getYear()+":"+localDate.getMonth()+":"+
			localDate.getDayOfMonth());
	
	//LocalDate.of  一定要填三個參數
	LocalDate loaclDate810 = LocalDate.of(2020, 8, 10);
	//localDate 晚於 loaclDate810 嗎？
  	 System.out.println(localDate.isAfter(loaclDate810));
	 //localDate 早於 loaclDate810 嗎？
	 System.out.println(localDate.isBefore(loaclDate810));
	
    }
    
}

