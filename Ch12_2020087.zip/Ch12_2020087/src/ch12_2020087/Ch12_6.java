/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_2020087;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
public class Ch12_6 {
    public static void main(String[] args) {
	// TODO code application logic here
	LocalDateTime localDateTime = LocalDateTime.now();
	System.out.println(localDateTime);
	 LocalDateTime pluseDateTime =
		 localDateTime.plus(1,ChronoUnit.DAYS);	 
	System.out.println(pluseDateTime);
	// LocalDateTime.of 最少需要年　月　日　小時　分鐘
	//LocalDateTime.of(0, 0, 0, 0, 0)
    }
    
}
