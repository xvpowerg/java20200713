/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_2020087;
import java.util.ArrayList;
import java.util.Optional;
public class Ch12_3 {
    public static void main(String[] args) {
	ArrayList<Integer> list = new ArrayList();
	list.add(10);
	list.add(20);
	list.add(50);
	list.add(40);
	//reduce 累運算
//	Optional<Integer> op = list.stream().reduce((v1,v2)->{    	    
//	    System.out.println(v1+":"+v2);
//	    return v1+v2;});	
//	op.ifPresent(c->System.out.println("ans:"+c));
//	//下方的reduce可設定初始值
//	Integer ans = list.stream().reduce(17, (v1,v2)->{
//		    System.out.println(v1+":"+v2);
//	    return v1 + v2;
//	});	
//	System.out.println("ans:"+ans);

//大數據再使用
//使用parallel後會先 呼叫accumulator 在此方法內 v2與 n的數值做計算
//在呼叫 combiner 做合併運算
//注意計算順序不一定
int n = 1;
int ans3 = list.stream().parallel().reduce(n, (v1,v2)->{
	   System.out.println("accumulator:"+v1+":"+v2);
	    return v1 * v2;
	}, (v3,v4)->{
	    System.out.println("combiner:"+v3+":"+v4);
	    return v3 * v4;
	});
    System.out.println(ans3);
    }
    
}
