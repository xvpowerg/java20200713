/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_2020087;

import java.util.ArrayList;
import java.util.Map;
import java.util.List;
import java.util.stream.Collectors;

/**
 *
 * @author xvpow
 */
public class Ch12_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	ArrayList<String> list1 = new ArrayList<>();
	list1.add("Apple");
	list1.add("Banana");
	list1.add("Cherry");
	list1.add("Vivin");
	list1.add("Lindy");
	list1.add("Joy");
	list1.add("Ken");
	list1.add("Iris");
	
	Map<Integer,List<String>> group = 
		list1.stream().collect(Collectors.groupingBy(v->v.length()));
	System.out.println(group);
	
	Map<Boolean,List<String>>  partGroup = 
		list1.stream().collect(Collectors.partitioningBy(v->v.length() > 4));
	System.out.println(partGroup);
	
	//joining 第一個參數 表示每個文字的中間 第二個參數 表示開頭  第三個參數  表示結尾
	String join = list1.stream().collect(Collectors.joining(",", "Names:", "."));
	System.out.println(join);	
    }
    
}
