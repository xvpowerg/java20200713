/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_2020087.io;

/**
 *
 * @author xvpow
 */
public class Ch12_10 {
    
    static void testFinally(){
	    System.out.println("Start!!");
	    try{
	       return;
	      // throw new IllegalArgumentException("Test!!!");
	    }finally{
		//一定要執行一的事情
		System.out.println("finally!!");
	    }
	}
    
    public static void main(String[] args) {
	
	testFinally();
    }
    
}
