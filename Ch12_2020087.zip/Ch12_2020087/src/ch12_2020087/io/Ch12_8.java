/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_2020087.io;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.FileOutputStream;
import java.io.BufferedInputStream;
import java.io.OutputStream;
import java.io.FileNotFoundException;
import java.io.BufferedOutputStream;
import java.io.IOException;
public class Ch12_8 {
    public static void main(String[] args) {
	File file = new File("C:\\mydir\\test.zip");
	File copyFile = new File("C:\\mydir\\copy_test.zip");
	InputStream inStr = null;
	 OutputStream outStr = null;
	try{
	    inStr = new FileInputStream(file);
	    inStr = new BufferedInputStream(inStr);
	    outStr = new FileOutputStream(copyFile);
	    outStr = new BufferedOutputStream(outStr);
	    int data = -1;
	    while( (data = inStr.read()) != -1){		
		outStr.write(data);		
	    }	 
	}catch(FileNotFoundException ex){
	    System.out.println(ex);
	}catch(IOException ex){
	   System.out.println(ex);
	}finally{//finally 一定會被執行一次的區塊
	    try{
		outStr.close();
		inStr.close();
	    }catch(IOException ex){
		System.out.println(ex);
	    }
	 
	}
	
	
    }
    
}
