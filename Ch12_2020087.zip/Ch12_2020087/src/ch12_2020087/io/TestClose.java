/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_2020087.io;

/**
 *
 * @author xvpow
 */
public class TestClose implements AutoCloseable {
    private String name;
    public TestClose(String name){
	this.name = name;
    }    
    public String toString(){
	return name;
    }
    public void close()throws Exception{
	System.out.println(name);	
    }
}
