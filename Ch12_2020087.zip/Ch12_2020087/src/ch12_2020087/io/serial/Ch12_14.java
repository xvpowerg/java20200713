/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_2020087.io.serial;
import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class Ch12_14 {
    public static void main(String[] args) {
	//序列化
	//把物件變序列化檔案
	File file = new File("c:\\mydir\\student.obj");
	Student st1 = new Student("Vivin",26,178.25f);
	try(FileOutputStream fout = new FileOutputStream(file);
	    ObjectOutputStream oout = new ObjectOutputStream(fout);){
	    oout.writeObject(st1);//序列化
	}catch(FileNotFoundException ex){
	    System.out.println(ex);
	}catch(IOException ex){
	    System.out.println(ex);
	}
	
    }
    
}
