/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_2020087.io.serial;
import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
public class Ch12_15 {

    public static void main(String[] args) {
	//反序列化
	//反序列化檔案變物件	
	File file = new File("c:\\mydir\\student.obj");
	try(FileInputStream fin = new FileInputStream(file);
	    ObjectInputStream oin = new ObjectInputStream(fin);	){
	   Student st1 =  (Student)oin.readObject();
	   System.out.println(st1);
	   //能使用|左右不能有關係
	}catch(FileNotFoundException | ClassNotFoundException ex){
	    System.out.println(ex);
	 }catch(IOException ex){
	    System.out.println(ex); 
	 }
	
    }
    
}
