/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20200724.testStatic;

/**
 *
 * @author xvpow
 */
public class MixBlockOrder {
    {
    System.out.println("Block 1");
    }   
    MixBlockOrder(){
	System.out.println("MixBlockOrder()");
    }    
    static{
      System.out.println("static Block 1");
    }
    static{
       System.out.println("static Block 2");
    }

    {
     System.out.println("Block 2");
    }
   
   
}
