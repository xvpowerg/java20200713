/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20200724.testStatic;

/**
 *
 * @author xvpow
 */
public class Ch6_5 {
     public static void main(String[] args){
	 //測試靜態與非靜態行為
	 //靜態 時資源共享
	 //非靜態時 資源獨立
	 Product p1 = new Product();
	 Product p2 = new Product();
	 p1.name = "Ken";
	 p1.price = 72;
	 
	 p2.name = "Vivn";
	 p2.price = 25;
	 
	 System.out.println(p1);
	 System.out.println(p2);
	 
	 
     }
}
