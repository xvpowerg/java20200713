/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20200724.testStatic;

/**
 *
 * @author xvpow
 */
public class Ch6_8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	//初始化區塊順序
	//靜態初始化區塊
	//呼叫順序:依照Block宣告順執行
	//呼叫次數:第一次載入類別時呼叫 只有１次
	//載入類別	
	StaticInitBlockOrder.value = 20; 
	StaticInitBlockOrder.value = 60; 
    }
    
}
