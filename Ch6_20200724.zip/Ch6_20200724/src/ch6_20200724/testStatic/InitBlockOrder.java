/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20200724.testStatic;
public class InitBlockOrder {
    {
    System.out.println("Block1!!");
    }
    
    InitBlockOrder(){
	System.out.println(" InitBlockOrder()");
    }
    
    {
    System.out.println("Block2!!");
    }
}
