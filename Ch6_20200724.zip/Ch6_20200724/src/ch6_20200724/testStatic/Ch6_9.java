/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20200724.testStatic;
public class Ch6_9 {
    public static void main(String[] args) {
	//呼叫順序
	//靜態區塊
	//非靜態區塊
	//建構子
	MixBlockOrder mb1 = new MixBlockOrder();
	MixBlockOrder mb2 = new MixBlockOrder();
	
    }    
}
