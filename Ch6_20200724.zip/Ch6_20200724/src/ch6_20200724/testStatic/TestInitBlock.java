/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20200724.testStatic;
import java.util.Arrays;
public class TestInitBlock {
    private String[] names 
	    = new String[100];
    private static int[] scores = new int[100];
    
    //Initializer block 
    {
    //會在建構式之前呼叫
        Arrays.fill(names, "Empty");
    }
    
    static{
	 Arrays.fill(scores, -1);
    }
    
    TestInitBlock(){
	System.out.println(names[80]);
    }
    public static int getScores(int index){
	return scores[index];
    }
    
}
