/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20200724;

public class Employee {
    private String name;
    private int salary;
    private int age;
    Employee(){}
    public void setName(String name){
	this.name = name;
    }
    public void setSalary(int salary){
	this.salary = salary;
    }
    //拋出例外 Exception
    public void setAge(int age)throws Exception{
	if (age < 20 || age > 100){
	    System.out.println("年齡必須20~100");
	    throw new Exception();
	}
	this.age = age;
    }    
    public String toString(){
	return name+":"+age+":"+salary;
    }
    
}
