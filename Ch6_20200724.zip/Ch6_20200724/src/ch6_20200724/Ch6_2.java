/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20200724;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.sql.SQLException;
/**
 *
 * @author xvpow
 */
public class Ch6_2 {
    //try catch 位置表示當例外發生時要解決問題
    //必要例外檢測
   // throw 拋出例外 表示例外已發生
    //throws 這個方法可能發生什麼例外?
    static void testCheckedException(int v)throws IOException,SQLException{
	if (v< 10){
	    throw new IOException();
	}
	  if(v > 100){
	      throw new SQLException();
	  }
    }
    //非必要例外檢測
    static void testUncheckedException(String str){
	if (str == null || str.isEmpty()){
	    throw new IllegalArgumentException();
	}	
    }
    
    
    public static void main(String[] args){
		//2 非必要例外檢測(unchecked exceptions)
		//適用於 嚴重性低的例外 
	   //extends RuntimException 
	   try{
	     testUncheckedException("");   
	   }catch(IllegalArgumentException ex){
		System.out.println(ex);
	   }
	
	
	//例外有兩種
	//1 必要例外檢測(checked exceptions) 強制開發人員 try catch 或拋出
	//適用於 嚴重性高的例外 
	    //直接extends Execption都是必要例外檢測 除了RuntimException
	 // 可以選擇 throws IOException,SQLException  但應用會中斷 對使用者的體驗不好
	 //catch 順序是有規則的 越下越父
	 
	 //FileNotFoundException 是 IOException 的子類
	 try{
	     testCheckedException(200);   
	 }catch(IOException ex){
	     System.out.println(ex);	 
	 }catch(SQLException ex){
	     System.out.println(ex);	 
	 }catch(Exception ex){
	      System.out.println(ex);
	 }
	    
	    

	  
	   
    }
    
}
