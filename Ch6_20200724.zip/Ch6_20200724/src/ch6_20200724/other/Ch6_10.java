/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20200724.other;

/**
 *
 * @author xvpow
 */
public class Ch6_10 {

  
    public static void main(String[] args) {
	String data = "Ken,Vivin,Lindy,Iris";
	//依據某個分割條件 分割字串
	String[] names =  data.split(",");
	for (String name : names){
	    System.out.println(name);
	}	
	
	String str = "abcbac";
	//左往右
	//找不到回傳-1
	int index = str.indexOf("b");
	System.out.println(index);
	//右往左找
	int index2 =  str.lastIndexOf("b");
	System.out.println(index2);	
	String str2 = "abc bac";
	//全部取代
	String newStr = str2.replaceAll("a", "A");
	System.out.println(newStr);
    }
    
}
