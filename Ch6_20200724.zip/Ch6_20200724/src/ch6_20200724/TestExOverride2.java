/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20200724;

/**
 *
 * @author xvpow
 */
public class TestExOverride2  extends TestExOverride1{
    //method1() 可選擇 拋出Exception
    //或是 不拋出
    //或是 子類(SalaryException)
     public void method1()throws SalaryException{
    }
    //method2() 可選擇 SalaryException
     //或是 不拋出
    public void method2()throws SalaryException{
    }
    //不可拋出必要例外檢測 
    //其他例外都可以
     public void method3()throws IllegalArgumentException{
	
    }
}
