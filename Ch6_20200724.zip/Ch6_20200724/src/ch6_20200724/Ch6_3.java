/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20200724;

/**
 *
 * @author xvpow
 */
public class Ch6_3 {
    //必要例外檢測 直接繼承Exception
   static void testSalaryException(int salary)throws SalaryException{
       if (salary < 20000){
	   throw new SalaryException("薪資不可小於20000");
       }
   }
   //非必要例外檢測 直接繼承RuntimeException
   static void testNameException(String name){
       if (name == null || name.isEmpty()){
	   throw new NameException("姓名不可空白");
       }       
   }
   
    public static void main(String[] args) {
	// TODO code application logic here
	try{
	    testSalaryException(3000);
	}catch(SalaryException ex){
	    System.out.println(ex);
	}
	
	testNameException(null);
    }
    
}
