/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20200724;

/**
 *
 * @author xvpow
 */
public class Ch6_4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)throws SalaryException {
	//例外拋出的覆寫
	//例外拋出 子類覆寫 可不拋可拋出一樣 或拋出子類型 "針對必要例外檢測"	
	//非必要例外檢測 只要不拋出必要例外檢測即可
	TestExOverride2 tx = new TestExOverride2();
	tx.method1();
	
    }
    
}
