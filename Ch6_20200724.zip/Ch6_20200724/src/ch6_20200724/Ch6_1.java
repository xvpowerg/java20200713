/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20200724;

/**
 *
 * @author xvpow
 */
public class Ch6_1 {
    public static void main(String[] args) {
		//Override規則
	//0 覆寫方法或類別必須擁有讀取權限時以下規則才成立
	   //當類別是default讀取權限時 無法跨pkcakge讀取 所以無法Override 
	//1 讀取權限只能開放不封閉
	 //TestModifier1
	//2 回傳值如果是基本型態必須一樣
	//TestOverride1
	//3 回傳值如果是參考型態可以跟父類別方法一樣或子類型
	//TestOverride1
	//4 方法名稱要一樣 傳入的類型與數量參數也要一樣
	//5 例外拋出 不拋 可拋出一樣 或子類型 "針對必要例外檢測"	
	
	//****
	//例外拋出 不拋 可拋出一樣 或子類型 "針對必要例外檢測"	
	Employee emp = new Employee();

	
	try{
	    emp.setName("Ken");
	    emp.setSalary(28000);
	    //20 ~ 100
	    //如果超過以上限制提示訊息 "年齡必須20~100"   
	     emp.setAge(-20);	  
	  System.out.println(emp);   
	}catch(Exception ex){
	    System.out.println(ex);
	}
	
	
	

    }    
}
