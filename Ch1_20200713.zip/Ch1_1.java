/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

public class Ch1_1 {
    //Java 執行入口
    public static void main(String[] args){
	//變數必須告知CPU 要宣告變數的大小 與 類型
 	//整數類型
	//byte 8bit -128 ~ 127
	//short 16bit -32768~32767
	//int 32bit -2147483648~2147483647  * 預設數值
	System.out.println(Integer.MAX_VALUE);
	System.out.println(Integer.MIN_VALUE);
	//long 64bit 
	System.out.println(Long.MAX_VALUE);//2^63-1 9223372036854775807
	System.out.println(Long.MIN_VALUE);//-2^63-9223372036854775808
	//= 指定運算子 
	//可把右邊的數值放到左邊去
	byte status = 1;
	System.out.println(status);
	//常用單位
	//1KB = 1024byte = 2^10 byte
	//1MB = 1024KB = 2 ^ 20 byte
	//1GB = 1024MB = 2 ^ 30 byte
	//1TB = 1024GB = 2 ^ 40 byte
	//浮點數 (有小數點的數)
	//float 32bit 6 精度
	//double 64bit 12精度 *預設數值
	//IEEE 754 模擬小數 
	//精準度比較高
	//BigInteger 嚴格一點的小數計算
	//BigDecimal 嚴格一點的小數計算
	//f 讓原本預設的double變為float
	float e = 2.71828f;
	double pi = 3.1415964;
	System.out.println(e);
	System.out.println(pi);
	System.out.println("Test!!!");	 
	  
    }
}
