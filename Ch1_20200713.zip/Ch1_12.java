/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author xvpow
 */
public class Ch1_12 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	//底線前後必須是底線或數字
	int a = 100_000_000;
	int b = 100_______000___000;
	float c = 12.7_56f;
	
    }
    
}
