/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author xvpow
 */
public class Ch1_5 {
    public static void main(String[] args){
	int a = 11;
	int b = 3;
	//整數除法得到商數
	System.out.println(a / b);
	//整數除法得到餘數
	System.out.println(a % b);
	//強制轉型 將除法運算中的元素轉為浮點數後
	//可得到一般除法的結果
	System.out.println((float)a/b);
//java.lang.ArithmeticException	
//	b = 0;
//	System.out.println(a / b);
	
	int n = 6;
	int s = 1231231231;
	System.out.println(s%n);//最終結果一定是 0~5
	
	
    }
}
