/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author xvpow
 */
public class Ch1_8 {
     public static void main(String[] args){
	 int a = 10;
	 int b = 20;
	 System.out.println(a > b);
	 System.out.println(a < b);
	 System.out.println(a >= b);
	 System.out.println(a <= b);
	 System.out.println(a == b);//等於
	 System.out.println(a != b);//不等於
     }
}
