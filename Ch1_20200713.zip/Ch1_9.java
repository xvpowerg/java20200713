/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author xvpow
 */
public class Ch1_9 {
    public static void main(String[] args) {
	
	//boolean　運算
	int a = 20;
	int b = 5;
	int c = 30;
	//and 雙邊成立回傳ｔｒｕｅ
	System.out.println(a > b && c > a );
	System.out.println(a > b && c < a );
	//or 單邊成立回傳ｔｒｕｅ
	System.out.println(a > b || c < a );
	//not true 的ｎｏｔ為ｆａｌｓｅ
	System.out.println(! (a > b) );
	//xor 一True 一False才為True
	System.out.println(a > b  ^ c < a);
	System.out.println(a > b  ^ c > a);
	
    }
    
}
