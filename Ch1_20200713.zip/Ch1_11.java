/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author xvpow
 */
public class Ch1_11 {
    public static void main(String[] args) {
	
	int count = 0;	
	count += 2;
	System.out.println(count);
	count -= 3;
	System.out.println(count);
	count *= 5;
	System.out.println(count);
	//小心
	float price = 2.5f;
	int sum = 10;
	sum += price;
	System.out.println(sum);
	
    }
    
}
