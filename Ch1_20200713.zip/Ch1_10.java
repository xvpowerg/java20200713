/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author xvpow
 */
public class Ch1_10 {
    public static void main(String[] args) {
	
	int i = 1;
	boolean b1 = i > 0 && ++i > 1;
	System.out.println(i);
	System.out.println(b1);
	int y = 1;
	//且的左邊為false會啟動短路  右邊不運行
	boolean b2 = y < 0 && ++y > 1;
	System.out.println(y);
	System.out.println(b2);
	//或的短路  左邊為true就不往右邊執行
	//短路未啟動
	int a = 1;
	boolean b3 = a > 3 || a++ > 1;
	System.out.println(b3);
	System.out.println(a);	
	//短路啟動
	int c = 1;
	boolean b4 = c < 3 || c++ > 1;
	System.out.println(b4);
	System.out.println(c);
    }
    
}
