/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author xvpow
 */
public class Ch1_3 {
    public static void main(String[] args){
	   //變數命名規則
	   //1 不可使用keyword
	   //https://docs.oracle.com/javase/tutorial/java/nutsandbolts/_keywords.html
	   //2 開頭可以是英文字母 or $ or _
	   //3 第二個字母開始可以使用　英文字母 數字 $ _
	   int price = 10;
	   int length1 = 26;
	   
	
    }
}
