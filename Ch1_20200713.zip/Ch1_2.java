/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author xvpow
 */
public class Ch1_2 {
    public static void main(String[] args) {
	//文字
	//字元 0~65535  16bit
	//一串字當中的元素
	 char c1= 'B';
	 char c2 = 'K';
	 System.out.println(c1);
	 System.out.println(c2);
	//字串
	String msg = "Book";	
	System.out.println(msg);
	char c3 = 65 ;
	System.out.println(c3);
	char c4 = 0 ;
	System.out.println(c4);
	char c5 = '三';
	//java會反查　把字元轉為數字
	int c5Int = c5;
	System.out.println(c5Int);
	//布林 表示true或false
	boolean isOpen = true;
	System.out.println(isOpen);
	isOpen = false;	
	System.out.println(isOpen);
    }
    
}
