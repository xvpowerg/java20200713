/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
public class Ch1_4 {
    public static void main(String[] args) {
	//算式中間如果有浮點數 結果會轉為浮點數
	int a = 10;
	int b = 20;
	System.out.println(a + b);
	float c = 1.52f;
	System.out.println(a + c);
	//加法運算中間如果有字串 結果會轉為字串
	String msg = "close!!";
	System.out.println("Error:"+ msg);
	int x = 25;
	int y = 32;
	System.out.println("value:"+x+y);
	System.out.println(x+y+":value");
    }
}
