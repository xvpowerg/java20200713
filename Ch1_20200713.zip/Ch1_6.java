/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

public class Ch1_6 {
     public static void main(String[] args){
	 //1元累加運算
	 int i = 0;
	 i++;
	 i++;
	 System.out.println(i);
	 i--;
	 System.out.println(i);
	 ++i;
	 ++i;
	 System.out.println(i);
	 
	 int k = 0;
	 System.out.println(k++);
	 //k++分解
//	 System.out.println(k);
//	 k = k + 1;
	 
	  System.out.println(++k);
	  //++k分解
//	 k = k +1;
//	 System.out.println(k);
     }
}
