/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20200731;
import java.util.function.Predicate;
public class Ch9_3 {

   //匿名內部類作用
    //1 快速覆寫(Override)物件方法
    //2 快速實作介面或覆寫抽象方法
   
    static void testDogBark(Dog dog){
	dog.bark();
    }
    static void printArray(int[] array,Predicate<Integer> p){
	for (int v :array){
	    if (p.test(v))
		System.out.println(v);
	}
    }
    public static void main(String[] args) {
	
	int[] array = {2,5,6,7,8,9,10};
	
	printArray(array,new Predicate<Integer>(){	    
	    public boolean test(Integer i){
		return i % 2 == 0;
	    }
	});
	
	
	// TODO code application logic here
	Dog dog1 = new Dog();
	testDogBark(dog1);
	Dog dog2 = new Dog(){
	    public void bark(){
		System.out.println("喵～");
	    }
	};
	testDogBark(dog2);
	
	testDogBark(new Dog(){
	    public void bark(){
		System.out.println("支支！！");		
	    }	
	});
	
	
	
	
	
    }
    
}
