/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20200731;

/**
 *
 * @author xvpow
 */
public class Number {
    private int value1;
    private int value2;
    
    private static abstract class Calculate{
	public abstract int calculate();
    };
    
   public  class Add extends Calculate{
	public int calculate(){
	    return value1 + value2;
	}
    }
   
    public  class Minus extends Calculate{
	public int calculate(){
	    return value1 - value2;
	}
    }
    
    Number(int value1,int value2){
	this.value1 = value1;
	this.value2 = value2;
    }
    
   public int ans(Calculate calcu){
	return calcu.calculate();
    }
   
   //因為ｔｅｓｔ方法為非靜態的 
   //能呼叫到ｔｅｓｔ（）時 表示Number物件已產生
   //所以可以看到Add類別 
   //於是可以直接使用new Add
   public void test(){
       Add add1 = new Add();       
   }
    
}
