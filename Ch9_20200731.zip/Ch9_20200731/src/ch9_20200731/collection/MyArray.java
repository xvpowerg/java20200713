/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20200731.collection;
import java.util.Iterator;
public class MyArray  implements Iterable<Integer>{
    private Integer[] array = new Integer[10];
    private int index = -1;
    private int maxIndex = array.length;
 
    public Iterator<Integer> iterator(){
	return new MyIterator(); 
    }
    
    public void add(int v){
	if (index + 1 < maxIndex){
		++index;
	    array[index] = v;
	}
    }
    public int get(int index){
	if (index >=0 && index < maxIndex ){
	   return  array[index];
	}
	return 0;
    }
    
     private class MyIterator implements Iterator<Integer> {
	    int  itIndex = 0;
	    public boolean hasNext(){
		return itIndex <= index;
	    }
	    public Integer next(){
		return array[itIndex++];
	    }
    }
    

}
