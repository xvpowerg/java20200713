/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20200731.collection;

/**
 *
 * @author xvpow
 */
public class Ch9_10 {
    //不需要import 在java.lang 的package都不需要import
    //不需要import 在相同Package
     public static void main(String[] args) {
	 MyArray myArray = new MyArray();
	 myArray.add(10);
	 myArray.add(30);
	 myArray.add(60);

	 
     }
}
