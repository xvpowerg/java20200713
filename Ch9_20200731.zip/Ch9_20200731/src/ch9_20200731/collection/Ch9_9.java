/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20200731.collection;
import java.util.ArrayList;
public class Ch9_9 {
    public static void main(String[] args) {
	//ArrayList<Integer> 限定ArrayList只能裝Integer
	ArrayList<Integer> list = new ArrayList();	
	list.add(20);//20自動封箱
	list.add(50);
	list.add(5);
	int sum = 0;
	for (Integer obj : list){
	    sum += obj;
	}
	System.out.println(sum);
    }
    
}
