/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20200731.lambda;


public class Ch9_4 {
    //lambda 使用介面模擬方法的一種表達示
    //寫lambda時要觀察 介面的抽象方法
    static void playBtn(Play play){
	play.playing();
    }
    public static void main(String[] args) {
	//匿名內部類幫我把Play實作完成
	
	Play play = new Play(){
		public void playing(){
		   System.out.println("Play Youtube");
		}
	};
	playBtn(play);//希望輸出Play Youtube
	play = ()->{
		System.out.println("Play Music");
	    };
	playBtn(()->System.out.println("Play Music"));
    }
    
}
