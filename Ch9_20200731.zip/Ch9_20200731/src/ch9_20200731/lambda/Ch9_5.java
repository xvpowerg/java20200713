/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20200731.lambda;
import java.util.function.Consumer;

public class Ch9_5 {

    static void testConsumer(String str,
			    Consumer<String> consumer){
	consumer.accept(str);
    }
    
    public static void main(String[] args) {
	testConsumer("abc",(String v)->{
	   System.out.println(v.toUpperCase());
	});
	testConsumer("abc",(x)->{
	      System.out.println(x.toUpperCase());
	});
	//lambda 不加上()的 只相容 一個參數的
	//如果沒參數 或是 參數為一個以上的都必須加上()
	//一個參數以上的必須加上()
	testConsumer("abc",y->{
	  System.out.println(y.toUpperCase());
	});
	//沒加上{}的lambda ->後只能是一條命令
	//->的命令不可加上;
	testConsumer("abc",g-> System.out.println(g.toUpperCase()));
    }
    
}
