/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20200731.lambda;
import java.util.function.Function;
public class Ch9_8 {

    static byte[] sringToByteArray(String str,Function<String,byte[]> fun){
	return fun.apply(str);
    } 
    
    static byte[] toByteArray(String str){
	
	return str.getBytes();
    }
    public static void main(String[] args) {
	// TODO code application logic here
	sringToByteArray("Ken", str->str.getBytes());
	//method reference
	sringToByteArray("Ken",Ch9_8::toByteArray );
    }
    
}
