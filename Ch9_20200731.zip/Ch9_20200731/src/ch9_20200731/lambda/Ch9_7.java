/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20200731.lambda;
import java.util.function.BinaryOperator;

public class Ch9_7 {
    static int calculate(int v1,int v2,BinaryOperator<Integer> bio){
	return bio.apply(v1, v2);
    }
    public static void main(String[] args) {
	// TODO code application logic here
	int v1 = calculate(30,2,
		(Integer a1,Integer a2)->{
		    return a1 +a2;});
	
	int v2 = calculate(30,2,
		( a1,a2)->{
		    return a1 *a2;});
	
	int v3 =calculate(30,2,( a1,a2)->a1-a2);
	System.out.println(v1+":"+v2+":"+v3);
	
    }
    
}
