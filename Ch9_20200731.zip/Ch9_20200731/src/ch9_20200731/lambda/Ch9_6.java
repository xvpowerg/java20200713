/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20200731.lambda;
import java.util.function.Function;
public class Ch9_6 {

    
    static String unicodeToString(int unicode,Function<Integer,String> fun){
	return fun.apply(unicode);
    }
    public static void main(String[] args) {
	
	unicodeToString(66,(Integer i)->{
	    int code = i;
	    char myChar = (char)code;	    
	    return myChar+"";
	});
	
	unicodeToString(66,(i)->{
	    int code = i;
	    char myChar = (char)code;	    
	    return myChar+"";
	});
	
	unicodeToString(66,i->{
	    int code = i;
	    char myChar = (char)code;	    
	    return myChar+"";
	});
	//方法如需要return時 以下lambda語法會將->後的命令的數值回傳
	String v = unicodeToString(69,i-> ((char)i.intValue())+""  );
	System.out.println(v);
    }
    
}
