/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20200731;

/**
 *
 * @author xvpow
 */
public class Student {
 
    //靜態內部類
    //靜態內部類無法讀取外部類的 非靜態屬性與方法
    //Book為內部類 Student外部類
    static class Book{
	private String bookName;
	private String author; 	
	Book(String bookName,String author){
		this.bookName = bookName;
		this.author = author;
	}
	public String toString(){
	    return bookName+":"+author;
	}
    }
    
   private String name;
   private String id;
   private Book[] books = new Book[5];
   private int index = -1;
   
   Student(String name,String id){
       this.name = name;
       this.id = id;
   }
   
      public void printBook(){
       for (Book b : books){
	   if (b!=null) System.out.println(b);
       }
     }
      
   public void addBook(Book book){
       index++;
       books[index] = book;
   }   
   
   public String toString(){
       return name+":"+id;
   }

   
   

}
