/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20200731;
import ch9_20200731.Student.Book;

public class Ch9_1 {
    //內部類
    // 某種類 只針對某個類別有功能
    // 這個類不知道該放在哪個package 
    //內部類可使用所有的讀取權限
    public static void main(String[] args) {
	Student st1 = new Student("Tom","A0001");
	System.out.println(st1);
	Book book1 = 
		new Book("android","Howard");
	Student.Book book2 = 
		new Student.Book("Swift", "Lindy");
	st1.addBook(book1);
	st1.addBook(book2);
	st1.printBook();
	
    }
    
}
