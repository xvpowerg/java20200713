/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20200731;

/**
 *
 * @author xvpow
 */
public class Ch9_2 {
     //Add 是一個非靜態的 內部類
    //必須透過外部類的物件才能使用
     static void testNumber(){
	Number n1 = new Number(10,20);
	Number.Add add=  n1.new Add();
	Number.Minus minus = n1.new Minus();
	System.out.println(n1.ans(add));
	System.out.println(n1.ans(minus));
    }
    
    public static void main(String[] args) {
	testNumber();
	
	
    }
    
}
