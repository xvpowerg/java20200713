/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20200722;

/**
 *
 * @author xvpow
 */
//extends 繼承
//java只能單一繼承
//只有看的到的方法會被繼承
//所有看不到的方法不會被繼承
//所有建構子也不會被繼承
public class Student extends Person{
    private int[] scores = new int[5];
    private int index = -1;
    private String classId = "";
    Student(){}
   Student(String name,int height,
	  float weight,String bloodType){
       //super() 呼叫父類別建構子
       //super() 只能是建構子的第一行命令       
       super(name,height,weight,bloodType);
//      this.setName(name);
//      this.setHeight(height);
//      this.setWeight(weoght);
//      this.setBloodType(bloodType);
   } 
   
   public void apendScore(int score){
       if (index + 1 == 5){
	   System.out.println("成績已滿");
	   return;
       }
       index++;
       scores[index] = score;
   }
   
   public void foreachScore(){
       for (int s : scores){
	   System.out.println("score:"+s);
       }
   }
   
   public void setClassId(String classId){
       this.classId = classId;
   }
   public String getClassId(){
       return classId;
   }
   
   //覆寫 Override
   //蓋過父類別的方法
   //@Override 檢查是否為正確的覆寫
   @Override
   public void print(){
       System.out.print("Student:");
       //super. 呼叫父類別的內容
       super.print();
   }
}
