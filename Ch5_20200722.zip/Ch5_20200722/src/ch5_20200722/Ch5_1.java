/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20200722;

public class Ch5_1 {
    public static void main(String[] args) {
	Person p1 = new Person();
	p1.setName("Ken");
	p1.setHeight(178);
	p1.setWeight(70);
	p1.setBloodType("A");
	p1.print();
	//String name,
	   // int height,float weight,String bloodType
	Person p2 = 
		new Person("Vivin",156,50,"O");
	p2.print();
	
	
    }
    
}
