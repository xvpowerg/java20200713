/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20200722;

/**
 *
 * @author xvpow
 */
public class Ch5_4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	//討論覆寫(Override)
	Student st1 = 
		new Student("Vivin",165,51,"B");
	st1.apendScore(95);
	st1.apendScore(70);
	st1.apendScore(63);
	st1.apendScore(84);
	st1.apendScore(53);
	st1.print();
	st1.foreachScore();
    }
    
}

