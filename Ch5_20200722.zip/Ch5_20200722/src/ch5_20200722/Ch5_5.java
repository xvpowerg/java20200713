/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20200722;

/**
 *
 * @author xvpow
 */
public class Ch5_5 {

  static void printPerson(Person ... ps){
      for (Person p : ps){
	  p.print();
      }      
  }
    
    public static void main(String[] args) {
	//Polymorphic
	//多形
	Person  p1 = new Student("Tom",172,63,"A");
	p1.print();
	//低耦合 變數與類別的相依關係是低的
	
	Student st1 = new Student("Vivin",178,75,"B");
	Student st2 = new Student("Tom",155,50,"O");
	Teacher t1 = new Teacher("Howard",180,71,"A");
	printPerson(st1,st2);
	
    }
    
}
