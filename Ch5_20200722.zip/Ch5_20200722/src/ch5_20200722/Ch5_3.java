/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20200722;

/**
 *
 * @author xvpow
 */
public class Ch5_3 {
    public static void main(String[] args) {
	//建構子 與 super 順序輸出練習
	Test3 t3 = new Test3(256);
    }
    
}
