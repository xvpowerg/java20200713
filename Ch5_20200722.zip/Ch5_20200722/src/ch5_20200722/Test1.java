package ch5_20200722;
public class Test1 {
    Test1(){
	this("A",20);
	 System.out.println("Test1()");
    }
    Test1(String s1,int value){
	System.out.println("Test1:"+s1+":"+value);
    }
}
