/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20200722.testoverride;

/**
 *
 * @author xvpow
 */
public class TestModifier1 {
     //討論 使用不同讀取權限的變數 
    //0 在相同類別內一定可讀取
    // 1 在不同類別內是否可讀取
    // 2 在不同package與類別內是否可讀取
    public String publicValue = "public";
    protected String protectedValue = "protected";
    String defaultValue = "default";
    private String privateValue = "private";
    
    public void testPublic(){
	System.out.println("Public");
    }
   protected void testProtected(){
	System.out.println("Protected");
    }
    void  testDefault(){
	System.out.println("Default");
    }   
    private void testPrivate(){
	System.out.println("Private");
    }
}
