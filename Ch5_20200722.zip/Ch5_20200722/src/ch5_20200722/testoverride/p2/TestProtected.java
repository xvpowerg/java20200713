/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20200722.testoverride.p2;
import ch5_20200722.testoverride.TestModifier1;
/**
 *
 * @author xvpow
 */
public class TestProtected extends TestModifier1 {
    void test(){
	System.out.println(this.protectedValue );
    }
}
