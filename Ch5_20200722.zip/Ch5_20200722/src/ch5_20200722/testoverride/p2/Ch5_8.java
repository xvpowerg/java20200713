/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20200722.testoverride.p2;
import ch5_20200722.testoverride.TestModifier1;
public class Ch5_8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	// 2 在不同package與類別內是否可讀取
	//因為TestModifier1 跟 Ch5_8 在不同package
	//所以必須import
	TestModifier1 t1 = new TestModifier1();
	System.out.println(t1.publicValue);
    }
    
}
