/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20200722.testoverride.p2;
import ch5_20200722.testoverride.TestModifier1;
/**
 *
 * @author xvpow
 */
// 2 在不同package 的 Override
public class TestModifier3 extends TestModifier1 {
     //只能public
    @Override
    public void testPublic(){
	System.out.println("TestModifier3 Public");
    }
    // protected public
        @Override
    protected void testProtected(){
	System.out.println("TestModifier3 Protected");
    }
    //因為跨package所以testDefault方法沒有被繼承所以無法覆寫
    void testDefault(){
	System.out.println("TestModifier2 Default");
    }
//根本不是覆寫 因為是private    
    private void testPrivate(){
	System.out.println("TestModifier2 Private");
    }
}
