/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20200722.testoverride;

/**
 *
 * @author xvpow
 */
public class TestModifier2 extends TestModifier1 {
     // 1 在不同類別內的Override狀況
    //只能public
    public void testPublic(){
	System.out.println("TestModifier2 Public");
    }
    // protected public
    protected void testProtected(){
	System.out.println("TestModifier2 Protected");
    }
    //default protected public
    void testDefault(){
	System.out.println("TestModifier2 Default");
    }
//根本不是覆寫 因為是private
    private void testPrivate(){
	System.out.println("TestModifier2 Private");
    }
}
