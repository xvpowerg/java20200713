/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20200722.testoverride;

/**
 *
 * @author xvpow
 */
public class Ch5_7 {
    public static void main(String[] args) {
	//1 讀取權限只能開放不封閉
	//讀取權限	
	//public  跨package可讀取
	//protected 跨package不可讀取 除非繼承了protected讀取權限所在類別，
	      //	則可在子類型讀取protected
	//default(沒有輸入讀取權限時)跨package不可讀取
	//private 只有在private所在類別內可讀取
	
	// 1 在不同類別內是否可讀取
	TestModifier1 tm1 = new TestModifier1();
	System.out.println(tm1.publicValue );
	System.out.println(tm1.protectedValue );
	System.out.println(tm1.defaultValue );
		
    }
    
}
