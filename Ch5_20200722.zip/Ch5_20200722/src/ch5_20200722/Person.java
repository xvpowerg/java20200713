package ch5_20200722;
public class Person {
    private String name;    
    private int height;
    private float weight;
    private String bloodType;
    Person(){
	System.out.println("Person()");}
    Person(String name,
	    int height,float weight,String bloodType){
	//this. 表示目前物件
	this.name = name;
	this.height = height;
	this.weight = weight;
	this.bloodType = bloodType;
    }    
    public String getName(){
	return name;
    }    
    public void setName(String inName){
	  name = inName; 
    }
    public int getHeight(){
	return height;
    }
    public void setHeight(int inHeight){
	height = inHeight;
    }   
     public float getWeight(){
	return weight;
    }
    public void setWeight(float inWeight){
	weight = inWeight;
    }
     public String getBloodType(){
	return bloodType;
    }
    public void setBloodType(String inBloodType){
	bloodType = inBloodType;
    }    
    public void print(){
	System.out.println(this.getName()+":"+this.getHeight()+":"+
		this.getWeight()+":"+getBloodType());
    }
}

