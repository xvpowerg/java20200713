/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20200722;

/**
 *
 * @author xvpow
 */
public class TestClass2 extends TestClass1{
    //所有建構子 如果沒有手動呼叫this或是super
    //都會預設呼叫super()
    
    //如果沒有手動建立任何一組建構子的狀態下
    //java會自動補上一組預設建構子
    //預設建構子 
    public TestClass2(){
	   super();
    }
}
