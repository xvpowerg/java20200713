/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20200722;


public class Test3  extends Test2{
    
    Test3(){
	super(20);
	System.out.println("Test3()");
    }
     Test3(int number){
	 this();
	 System.out.println("Test3(Int):"+number);
     }
}
