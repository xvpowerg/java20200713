/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20200717;

/**
 *
 * @author xvpow
 */
public class Ch3_1 {

    public static void main(String[] args) {
	//多維陣列
	//左邊的[]數的總量 等於右邊的總量
	int[][] array = new int[3][5];
	array[0][0] = 15;
	array[0][2] = 20;
	array[1][1] = 75;
	array[1][3] = 47;
	array[2][0] = 83;
	array[2][2] = 91;
	
	// array.length row的長度
//	for (int r =0;r <array.length ;r++){
//	    //array[r].length colum的長度
//	    for (int c = 0; c<array[r].length;c++){
//		System.out.print(array[r][c]+" ");
//	    }
//	        System.out.println();
//	}
//	for (int i = 0; i < array.length;i++){
//	    int[] a = array[i];
//	    for (int k =0 ; k <a.length;k++){
//		int v = a[k];
//		System.out.print(v+" ");
//	    }
//	    System.out.println();
//	}
	
	for (int[] array1: array){
	    for (int v : array1){
		System.out.print(v+" ");
	    }  
	     System.out.println();
	}
	
	
    }
    
}
