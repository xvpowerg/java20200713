/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20200717;

/**
 *
 * @author xvpow
 */
public class Ch3_9 {

    public static void main(String[] args) {
	//Boolean.parseBoolean 不會拋出例外 
	//不分大小寫只要是true 就回傳true  其他就回傳false
	 boolean b1 =  Boolean.parseBoolean("true");
	 System.out.println(b1);
	 b1 =  Boolean.parseBoolean("tRUe");
	System.out.println(b1);
	b1 = Boolean.parseBoolean("t r u e");
	 System.out.println(b1);
	 b1 = Boolean.parseBoolean(null);
	 System.out.println(b1);
	Boolean boxing= Boolean.valueOf(null);
	 System.out.println(boxing.booleanValue());
    }
    
}
