/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20200717;

/**
 *
 * @author xvpow
 */
public class Ch3_5 {
    //void 無回傳參數
    //function 方法名稱 只要符合變數規則即可
    //int x 傳入參數 虛引數(Parameter)
    static void function(int x){
	System.out.println(x);
	//離開方法
	return;
    }
    //overloading 多載
    static int abs(int x){
	//三元運算子
	//(條件)?(回傳條件成立的結果):(回傳條件不成立的結果)
	//return  表示 1 回傳數值 且 2 離開方法
	return  x < 0 ? x *-1 : x;
    }
    
    static float abs(float x){
	return x <0 ? x * -1 : x;
    }
    
    //直接呼叫只能static呼叫static的
    public static void main(String[] args) {
	// TODO code application logic here
	int y = 70;
	function(10);
	System.out.println(y);
	System.out.println(abs(-5));
	System.out.println(abs(2));
	System.out.println(abs(-3.5f));	
    }
    
}
