/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20200717;

public class Ch3_8 {

    public static void main(String[] args) {
	//安全
	//規定
	//封箱 針對基本型態
	//封箱 boxing 
	    //byte  Byte
	    //short Short
	    //int Integer
	    //long Long
	    //float Float
	    //double Double
	    //char Character
	    //boolean Boolean
	    
	    int age = 25;
	    //手動封箱 boxing
	    Integer objInt=Integer.valueOf(age);
	    //手動解封箱unboxing
	    int value = objInt.intValue();
	    System.out.println(value);
	    //阿拉伯數字的字串 轉為整數
	    int number = Integer.parseInt("128");
	    System.out.println(number+2);
	    // number = Integer.parseInt(null); //java.lang.NumberFormatException: null
	      // System.out.println(number);
// 自動封箱
    int a = 10;
    Integer boxingA = a;
// 自動解封箱
    int unBoxingA = boxingA;
    Integer boxingB = null;
//    int unBoxingB = boxingB;//java.lang.NullPointerException
//    System.out.println(unBoxingB);
    //補充
    //10 -> 2
    String b = Integer.toBinaryString(1234);
    //10 -> 8
    String o = Integer.toOctalString(1234);
    //10 -> 16
    String hex= Integer.toBinaryString(1234);
    
    System.out.println(b);
    System.out.println(o);
    System.out.println(hex);
	       
    }
    
}
