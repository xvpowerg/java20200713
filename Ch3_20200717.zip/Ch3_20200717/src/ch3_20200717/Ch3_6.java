/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20200717;
public class Ch3_6 {

    //... vargs 
    //vargs 只能放置於參數的最後一個位置
    //
    
    static int sum(int ... values){
	int ans = 0;
	for (int v : values){
	    ans += v;
	}
	return ans;
    }

    public static void main(String[] args) {
	//2 
	//5
	System.out.println(sum(2,5,9,2));	
	int[] price = {5,6,8,9};
	System.out.println(sum(price));
    }
    
}
