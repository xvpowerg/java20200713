/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20200717;
import java.util.ArrayList;
public class Ch3_4 {
    public static void main(String[] args) {
	ArrayList arrayList = new ArrayList();
	
	arrayList.add(10);//0
	arrayList.add(50);//1
	arrayList.add(86);//2
	arrayList.add(74);//3
	
	System.out.println(arrayList.get(2));//取得某個索引的數值
	
	for (Object v : arrayList){
	    System.out.println(v);
	}
	
    }
    
}
