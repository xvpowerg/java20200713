/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20200717;

/**
 *
 * @author xvpow
 */
public class Ch3_3 {

    public static void main(String[] args) {
	//非固定的形的陣列
	int[][] array = new int[3][];
	array[0] = new int[]{4,5,6,7};
	array[2] = new int[3];
	//array[2][1] = 9;
	//array[2][3] = 7;//java.lang.ArrayIndexOutOfBoundsException 超過index
	//array[1][0] = 75; //java.lang.NullPointerException


	
    }
    
}
