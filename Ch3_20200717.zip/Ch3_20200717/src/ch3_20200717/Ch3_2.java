/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20200717;

/**
 *
 * @author xvpow
 */
public class Ch3_2 {
    //多維陣列的宣告方式
    public static void main(String[] args) {
	int[][][] array = new int[3][2][1];
	int[][] array2[] = new int[2][3][5];
	int[] array3[][] = new int[2][3][5];
	int array4[][][] = new int[2][3][5];
	
	int[][][] array5 = { {
			     {1,2,3},{4,5,6}  
				}   };
	System.out.println(array5[0][1][2]);
	
	array5 = new int[][][]{  { {1,3,5},{7,8}  }	};
	System.out.println(array5[0][0][2]);
	System.out.println(array5[0][1][2]);
    }
    
}
