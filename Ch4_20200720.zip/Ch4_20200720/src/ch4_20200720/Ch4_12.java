/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20200720;

/**
 *
 * @author xvpow
 */
public class Ch4_12 {
    public static void main(String[] args) {
	String names = "Ken,Vivin,Join";
	//substring 取得 >=0  < 9
	String newStr =  names.substring(0, 9);
	System.out.println(newStr);
	
	for (int i =0; i < names.length();i++){
	    char c1 = names.charAt(i);
	    System.out.println(c1);
	}
	
	
    }
    
}
