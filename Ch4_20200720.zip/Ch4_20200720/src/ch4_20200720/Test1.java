/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20200720;

/**
 *
 * @author xvpow
 */
public class Test1 {
    //題型
    Test1(){
	this(10,"Value");
	System.out.println("()");
    }
    
    Test1(int a,int b){
	this();
	System.out.println("test(int int)");
    }
    
    Test1(int a,String b){
	System.out.println("int String:"+b);
    }
}
