/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20200720;

/**
 *
 * @author xvpow
 */
public class Ch4_8 {

   
    public static void main(String[] args) {
	Product p1 = new Product();
	//  長度不可小於0大於20 
	//不可為null
	//p1.name = "Ps4";
	p1.setName("");
	p1.setName("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
	p1.setName(null);
	p1.setPrice(-90);
	p1.print();
	
	
    }
    
}
