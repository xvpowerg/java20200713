/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20200720;
public class Student {
    //屬性 Attributes
    int age;
    String name;
    float height;
    float weight;
    void print(){
	System.out.printf("Name:%s Age:%d Height:%.2f Weight:%.2f%n",
			    name,age,height,weight);
    }
    
}
