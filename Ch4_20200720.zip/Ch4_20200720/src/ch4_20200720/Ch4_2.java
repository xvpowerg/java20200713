/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20200720;

/**
 *
 * @author xvpow
 */
public class Ch4_2 {

    static void swap( StringBuffer sb1,StringBuffer sb2){
	String tmp = sb1.toString();
	sb1.delete(0, sb1.length());//把StringBuffer清空
	sb1.append(sb2.toString());
	sb2.delete(0,sb2.length());
	sb2.append(tmp);
    }
    //String 因為無法修改 所以無法Swap
    static void swap(String s1,String s2){
	//????
    }
    public static void main(String[] args) {
	 StringBuffer sb1 = new StringBuffer();   
	 StringBuffer sb2 = new StringBuffer();   
	sb1.append("Ken");
	sb2.append("Vivin");
	System.out.println(sb1+":"+sb2);
	swap(sb1,sb2);
	System.out.println(sb1+":"+sb2);
    }
}
