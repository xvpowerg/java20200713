/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20200720;

/**
 *
 * @author xvpow
 */
public class Ch4_1 {
    //call by value
    static void swap(int a,int b){
	int tmp = a;
	a = b;
	b = tmp;
    }
    
    //call by reference
    static void swap(int[] array){
	    int tmp = array[0];
	    array[0] = array[1];
	    array[1] = tmp;
    }
    
    public static void main(String[] args) {
//	int a = 10;
//	int b = 20;
//	System.out.println(a+":"+b);
//	swap(a,b);
//	System.out.println(a+":"+b);

    int[] array = {60,70};
    System.out.println(array[0]+":"+array[1]);
    swap(array);
    System.out.println(array[0]+":"+array[1]);
    }
    
}

