/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20200720;

/**
 *
 * @author xvpow
 */
public class Ch4_9 {

    public static void main(String[] args) {

	Product p1 = new 
	   Product("iPhone",1000);	
	p1.print();
	
	Product p2 = new Product();
	p2.print();
    }
    
}
