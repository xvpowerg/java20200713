/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20200720;

/**
 *
 * @author xvpow
 */
public class Ch4_6 {
    public static void main(String[] args) {

	//一定有類別
	Student st1 = new Student();
	st1.name = "Ken";
	st1.age = 32;
	st1.height = 180;
	st1.weight = 75;
	Student st2 = new Student();
	st2.name = "Vivin";
	st2.age = 25;
	st2.height = 162;
	st2.weight = 53;
	
	System.out.printf("%s %d %.2f %.2f %n",
			  st1.name,st1.age,
			  st1.height,st1.weight);
	System.out.printf("%s %d %.2f %.2f %n",st2.name,st2.age,
					     st2.height,st2.weight);
	
    }
    
}
