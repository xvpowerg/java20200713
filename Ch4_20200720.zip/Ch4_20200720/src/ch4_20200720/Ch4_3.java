/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20200720;

/**
 *
 * @author xvpow
 */
public class Ch4_3 {
    
    //多載口訣
    //方法名稱一樣 參數的類型或數量不一樣
    
    //多載的自動搜尋條件優先順序
    //1 一樣類型
    //2 相同類型可相容 
    //3 不同類型可相同 
    //4 相同類型的封箱類型
    //多參數時 一定要有條件是非他不可的選項
    //相同類型可相容 
    static void test1(int value){
	System.out.println("Test1 Int");
    }
    static void test1(short value){
	System.out.println("Test1 short");
    }
    //不同類型可相同 
    static void test2(short value2){
	System.out.println("test2 short");
    }
     static void test2(float value2){
	System.out.println("test2 float");
    }
         //不同類型可相同 
      static void test3(Integer v){
	 System.out.println("Integer test3");
     }
     static void test3(float f1){
	 System.out.println("float test3");
     }     
     static void test4(Float f1){
	  System.out.println("Float test3");
     }
     static void test4(byte b1){
	 System.out.println("byte test4");
     }
     

    //overloading 多載
    public static void main(String[] args) {
	short s1 = 5;
	  //相同類型可相容 
	  test1(5);
 //不同類型可相同     
	//test2(6);
//不同類型可相同 
	//test3(20);	
	//編譯錯誤
	//test4(10);
    }
    
}
