/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20200720;

/**
 *
 * @author xvpow
 */
public class Product {
    private String name;
   //Encapsulation 封裝
   private int price;
   //Constructor 建構子
   //建構子特性
   //名稱跟類別一樣 沒有回傳值
   //預設建構子
   //沒特別需求 請加上預設建構子
   Product(){
       //this()呼叫目前類別的其他建構子
       //位置只能是建構子的第一命令      
      this("未設定",0);
   }
   
   Product(String inName,int inPrice){
       name = inName;
       price = inPrice;
   }
  
   public String getName(){
       return name;
   }
   
   public void setName(String inName){
         if (inName == null || inName.isEmpty() || inName.length() > 20 ){
	     System.out.println("錯誤的品名");
	     return;
	 }
       name = inName;
   }
   
   
   //取
   public int getPrice(){
       return price;
   }
   //存
   public void setPrice(int inPrice ){
       if (inPrice < 0 || inPrice > 20000000){
	   System.out.println("錯誤的金額!");
	   return;
       }
       price = inPrice;
   }
    void print(){
	System.out.println(name+":"+price);
    }
}
