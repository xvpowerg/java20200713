/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20200720;

/**
 *
 * @author xvpow
 */
public class Ch4_4 {
    //多載的自動搜尋條件優先順序
    //1 一樣類型
    //2 相同類型可相容 
    //3 不同類型可相同 
    //4 相同類型的封箱類型
    //多參數時 一定要有條件是非他不可的選項
    //相同類型可相容 
    static void test1(int a,float b){
	System.out.println("int float");
    }
     static void test1(int a,int b){
	System.out.println("int int");
    }
     
     static void test2(float a,int b){
	 System.out.println("float int");
     }
     static void test2(int a, float b){
	 System.out.println("int float");
     }
     
     static void test3(Integer a,int b,int x ){
	  System.out.println("Integer int int");
     }
     static void test3(int b,Integer c,float x ){
	 System.out.println("int Integer float");
     }
     
     static void test4(float a,int b,Integer x){
	 System.out.println("float int Integer");
     }
     //因為參數全為基本型態所以選擇此方法
     static void test4(int a,float b,int x){
	 System.out.println("int float int");
     }
     
    public static void main(String[] args) {
	// TODO code application logic here
	//test1(20,15);
	//因為沒有找到100%符合條件所以會出錯
	//test2(20,15);
	//test3(20,15,2.5f);
	test4(1,2,3);
	
    }
    
}
