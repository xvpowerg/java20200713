/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20200720;

/**
 *
 * @author xvpow
 */
public class Ch4_5 {
    //遞迴一定要有返回點
    static void loop(int n){
	System.out.println("Start:"+n);
	if (n <= 3){
	    System.out.println(n);
	    loop(n + 1);
	}
	System.out.println("End:"+n);
    }
	static int factorial(int n){
	    if (n == 1) return 1;
	    return n * factorial(n-1);
	}
    
    
    public static void main(String[] args) {
	//loop(1);	
	System.out.println(factorial(5));
    }
    
}
