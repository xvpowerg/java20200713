/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20200727.testabstract;


public abstract class Person {
   private  String name;
   private int height;
   Person(String name,int height){
       this.name = name;
       this.height  = height;
   } 
    public abstract void skill();
    
    public String toString(){
	return name+":"+height;
    }
}
