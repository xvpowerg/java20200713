/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20200727.testabstract;

/**
 *
 * @author xvpow
 */
public class Ch7_3 {
    public static void main(String[] args) {
	//抽象類別
	//一種統稱會設定為抽象類別
	//提醒開發人員必須完成某件事(覆寫某個抽象方法)
	//抽象類別不可new	
	//抽象類別不可final
	//final 的類別表示 不可被繼承
	//抽象方法不可final 與 private	
	//final 的方法表示 不可被覆寫
	//new Animal("",10);
	Animal dog  = new Dog("Snopy",25);
	System.out.println(dog);
	
	
    }
    
}
