/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20200727;

/**
 *
 * @author xvpow
 */
public class Ch7_1 {
    public static void main(String[] args) {
	
	//遮蔽 Shade
	//變數或靜態的所有類型都是遮蔽
	//遮蔽看類別
	//覆寫看物件
	
	TestShade1 t1 = new TestShade2();
	t1.noStaticMethod();
	//使用Shade 
	t1.staticMethod();//TestShade1 staticMethod
	System.out.println(t1.value);
	
    }
    
}
