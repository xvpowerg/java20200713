/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20200727;

/**
 *
 * @author xvpow
 */
public class TestShade3 {
    int value;
    static void staticMethod(){
	System.out.println("TestShade3 staticMethod!");
    }
    int getValue(){
	return value;
    }
    void setValue(int value){
	this.value = value;
    }
}
