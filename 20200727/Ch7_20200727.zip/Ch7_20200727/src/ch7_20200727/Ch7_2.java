/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20200727;

/**
 *
 * @author xvpow
 */
public class Ch7_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	//遮蔽 Shade
	//變數或靜態的所有類型都是遮蔽
	//遮蔽看類別
	//覆寫看物件	
	TestShade3 t4 = new TestShade4();
	t4.value = 25;
	System.out.println(t4.getValue());
    }
    
}
