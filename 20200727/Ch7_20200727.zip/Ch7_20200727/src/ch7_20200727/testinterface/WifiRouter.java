/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20200727.testinterface;

/**
 *
 * @author xvpow
 */
//類別跟介面的的關係是實作
//一個類別可實作多個介面
public class WifiRouter implements Wifi{
    public String getIp(){
	return "127.0.0.1";
    }
    public String getMac(){
	return "DF:AB:CE:AF";
    }
}
