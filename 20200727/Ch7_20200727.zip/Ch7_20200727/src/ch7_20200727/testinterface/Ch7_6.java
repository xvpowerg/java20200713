/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20200727.testinterface;

/**
 *
 * @author xvpow
 */
public class Ch7_6 {

    /**
     * @param args the command line arguments
     */    
    public static void main(String[] args) {
	//有一種介面稱為Functional Interface
	//用介面模擬方法
	//Functional Interface特色 抽象方法只有一組
	//模擬 Fly 介面的 flying 的方法
	//lambda 
	Fly fly = ()->{ 
	    //做flying的功能
	};
    }
    
}
