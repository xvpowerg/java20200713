/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20200727.testinterface;

/**
 *
 * @author xvpow
 */
public class Ch7_5 {

    public static void main(String[] args) {
	//介面
	//走 跑 跳 飛
	//藍芽 通訊界面  一種協定
	//WIFI 
	//介面內 基本的方法都是抽象的
	//介面與介面之間是繼承關係
	//介面與類別之間是實作
	
	Wifi wifi = new WifiRouter();
	System.out.println(wifi.getIp());
	System.out.println(wifi.getMac());
	
	IronManActionGroup ia = new Maak16();
	ia.flying();
	ia.runing();
	ia.walking();
	HeightSpeed hs = (HeightSpeed)ia;
	hs.turbo();
	ia.flying();
	//預設情況下介面的屬性是
	 //static final 
	System.out.print(Fly.MAX_LENGTH);
	
    }
    
}
