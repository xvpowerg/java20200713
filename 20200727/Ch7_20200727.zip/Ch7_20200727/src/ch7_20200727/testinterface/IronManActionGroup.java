/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20200727.testinterface;

//介面與介面之間是繼承關係
//有點像是把介面變為一個介面群組
public interface IronManActionGroup 
	extends Fly,Run,Walk {
    
}
