/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20200727.testinterface;

/**
 *
 * @author xvpow
 */
public class IronMan implements Fly,Run,Walk {
    public void flying(){
	System.out.println("IronMan flying");
    }
    public void runing(){
	System.out.println("IronMan runing");
    }
    public void walking(){
	System.out.println("IronMan walking");
    }
}
