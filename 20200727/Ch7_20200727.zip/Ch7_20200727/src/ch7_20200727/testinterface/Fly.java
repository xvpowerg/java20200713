/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20200727.testinterface;

/**
 *
 * @author xvpow
 */
public interface Fly {
    //預設情況下介面的屬性是
    //static final 
    int MAX_LENGTH = 500;    
    void flying();
}
