/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tw.com.erp;
import java.util.List;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.Files;
import java.io.IOException;

//class Test extends MyErp{
//     protected  void reportStyle(List data){
//	 System.out.println(data.size());
//     }
//}

public abstract class MyErp {
    //protected
    //相同package 看的到
    //不同package 要繼承才能看到
     protected List readData(){	 
	Path path =  Paths.get("c:", "mydir","data.txt");
	List list = null;
	try{
	 list = Files.readAllLines(path);   
	}catch(IOException ex){
	    System.out.println(ex);
	}	
	 return list;
     }
     protected abstract void reportStyle(List data);
     protected void exportReport(){
	 List data = readData();
	 reportStyle(data);
     }
     
//    public static void main(String[] str){
//	Test t1 = new Test();
//	t1.exportReport();
//    }
}
