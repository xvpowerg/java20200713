/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myerpreport;
import tw.com.erp.MyErp;
import java.util.List;
/**
 *
 * @author xvpow
 */
public class MyErpReport extends MyErp {
    public void reportStyle(List data){
	for (Object obj : data){
	    System.out.println(obj);
	}
    }
    public void exportReport(){
	super.exportReport();
    }
}
